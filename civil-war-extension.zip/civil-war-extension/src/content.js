/* Civil War - content script (isolated world). Holds the copied Shopee data for this tab and
 * answers the side panel. When no copy exists it reads the visible page:
 *   - title from the main <h1> (cross-checked with the browser tab title)
 *   - banners ONLY from the main gallery column (big image + thumbnail strip), never from colour/shade buttons
 */
(function () {
  'use strict';
  if (window.__pdpCaptureContent) return;
  window.__pdpCaptureContent = true;

  var store = {};          // itemId -> parsed record (from Shopee's own data)
  var apiSeen = [];        // paths of Shopee data requests seen on this page (debug info only)
  var apiFail = [];       // Shopee answers that could not be used (debug info only)
  var lastDom = null; var lastGallery = null;      // what the last visible-page scan found (debug info only)

  function idsFromQuery(url) {
    try {
      var u = new URL(url, location.origin);
      return {
        itemId: u.searchParams.get('item_id') || u.searchParams.get('itemid') || '',
        shopId: u.searchParams.get('shop_id') || u.searchParams.get('shopid') || ''
      };
    } catch (e) { return { itemId: '', shopId: '' }; }
  }

  function tellPanel() {
    try { chrome.runtime.sendMessage({ type: 'PDP_UPDATED' }, function () { void chrome.runtime.lastError; }); } catch (e) { /* ignore */ }
  }

  window.addEventListener('message', function (e) {
    if (e.source !== window) return;
    var d = e.data;
    if (!d || d.source !== 'pdp-capture-hook') return;
    if (d.seen) {
      var p = String(d.seen).slice(0, 120);
      if (apiSeen.indexOf(p) < 0 && apiSeen.length < 60) apiSeen.push(p);
      return;
    }
    try {
      try {
        var dd0 = d.data && d.data.data, pi = dd0 && dd0.product_images, iid = dd0 && dd0.item && String(dd0.item.item_id || '');
        if (pi && iid) {
          var got = [];
          (function walk(v, depth, key) {
            if (depth > 4 || got.length > 40) return;
            if (typeof v === 'string') { if (/^(images?|image_list|imageList|main_images|gallery|urls?)$/i.test(key || '') || /susercontent/.test(v) || /^[\w\-]{20,60}$/.test(v)) { var u = PDP.fullImageUrl(v); if (u && got.indexOf(u) < 0) got.push(u); } }
            else if (Array.isArray(v)) v.forEach(function (x) { walk(x, depth + 1, key); });
            else if (v && typeof v === 'object') Object.keys(v).forEach(function (k) { walk(v[k], depth + 1, k); });
          })(pi, 0, 'images');
          if (got.length) apiGallery[iid] = got;
        }
      } catch (e) { /* only a helper */ }
      var rec = PDP.parseShopeeResponse(d.data);
      if (!rec || !rec.title || !rec.images.length) {
        // for the debug info: what did Shopee's answer look like, and why was it not used
        var dd = d.data && d.data.data;
        apiFail.push({ path: String(d.url || '').split('?')[0].slice(-40), error: d.data && d.data.error, topKeys: Object.keys(d.data || {}).slice(0, 12),
          dataKeys: dd && typeof dd === 'object' ? Object.keys(dd).slice(0, 25) : null,
          itemKeys: dd && dd.item && typeof dd.item === 'object' ? Object.keys(dd.item).slice(0, 40) : null,
          productImages: (function () { var p = d.data && d.data.data && d.data.data.product_images; return p && typeof p === 'object' ? { type: Array.isArray(p) ? 'array' : 'object', keys: Array.isArray(p) ? p.length : Object.keys(p).slice(0, 10), picked: Object.keys(apiGallery).length } : null; })(),
          parsed: rec ? { title: !!rec.title, images: rec.images.length } : null });
        if (apiFail.length > 4) apiFail.shift();
        return;
      }
      var q = idsFromQuery(d.url);
      if (!rec.itemId) rec.itemId = q.itemId;
      if (!rec.shopId) rec.shopId = q.shopId;
      if (!rec.itemId) return;
      var old = store[rec.itemId];
      if (!old || (rec.description && rec.description.length >= (old.description || '').length)) store[rec.itemId] = rec;
      tellPanel();
    } catch (err) { /* ignore */ }
  });

  // ---------- helpers for reading the page ----------
  function all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function clean(t) { return String(t || '').replace(/[​-‏⁠﻿]/g, '').replace(/\s+/g, ' ').trim(); }
  function norm(t) { return clean(t).toLowerCase().replace(/[^a-z0-9]/g, ''); }
  function rectOf(el) { var r = el.getBoundingClientRect(); return { l: r.left, t: r.top, r: r.right, b: r.bottom, w: r.width, h: r.height }; }

  // only real Shopee product pictures: susercontent.com/file/<id> or shopee.co.id/file/<id>; no data: placeholders, no empty src
  var CDN = /^https?:\/\/[^\/]*(?:susercontent\.com|shopee\.co\.id)\/file\/[\w\-.]{2,}/i;

  // image URL of an <img> or of an element with an inline background-image
  function elUrl(el) {
    var s = '';
    if (el.tagName === 'IMG') {
      if (el.complete && el.naturalWidth === 0 && (el.currentSrc || el.src)) return '';      // broken / blank picture
      s = el.currentSrc || el.src || '';
      if (!CDN.test(s)) s = el.getAttribute('data-src') || '';                                   // lazy-loading placeholder (data:image...) -> real address
    }
    if (!CDN.test(s)) {
      var st = el.getAttribute('style') || '';
      var m = st.match(/url\(\s*["']?([^"')]+)/);
      s = m ? m[1] : '';
    }
    return CDN.test(s) ? s : '';
  }
  function cdnEls(root) {
    return all('img,[style*="susercontent"]', root).filter(function (e) { return !!elUrl(e); });
  }

  function cleanTitle(t) {
    t = clean(t);
    // badges such as "Star+", "Mall" can sit in front of the title text
    t = t.replace(/^(Shopee Mall|Star\+|Star|Mall|Pilihan|Favorit\+?|Favorit)(?=[A-Z\[\(])/, '');
    return t.trim();
  }
  function tabTitle() {
    var t = clean(document.title).replace(/\s*[|\-–—]\s*Shopee( Indonesia)?\s*$/i, '');
    if (!t || /^shopee/i.test(t)) {
      var og = document.querySelector('meta[property="og:title"]');
      t = og ? clean(og.getAttribute('content')).replace(/\s*[|\-–—]\s*Shopee( Indonesia)?\s*$/i, '') : '';
    }
    return t;
  }

  // The product title. Candidates: the visible <h1> (text and title attribute), the browser-tab title, og:title and the
  // structured-data name. A title that ends in "…" or "..." is cut off, so the longest complete candidate wins; if all
  // are cut, the longest one is used.
  var ELLIPSIS = /\s*(\u2026|\.{2,})\s*$/;
  function isCut(t) { return ELLIPSIS.test(t); }
  function stripShopee(t) { return clean(t).replace(/\s*[|\-–—]\s*Shopee( Indonesia)?\s*$/i, ''); }
  function jsonLdName() {
    var out = [];
    all('script[type="application/ld+json"]').forEach(function (sc) {
      try {
        var j = JSON.parse(sc.textContent), arr = Array.isArray(j) ? j : [j];
        arr.forEach(function (o) { if (o && /product/i.test(String(o['@type'])) && o.name) out.push(clean(o.name)); });
      } catch (e) { /* not json */ }
    });
    return out;
  }
  function pickFullest(texts) {
    var list = texts.filter(function (t) { return t && t.length >= 8; });
    if (!list.length) return '';
    var whole = list.filter(function (t) { return !isCut(t); });
    var pool = whole.length ? whole : list.map(function (t) { return t.replace(ELLIPSIS, ''); });
    return pool.sort(function (x, y) { return y.length - x.length; })[0];
  }
  function findTitle() {
    var tt = tabTitle(), ttn = norm(tt);
    var cands = all('h1').map(function (h) { return { el: h, text: cleanTitle(h.textContent), r: rectOf(h) }; })
      .filter(function (c) { return c.text.length >= 8 && c.r.w > 0 && c.r.h > 0; });
    var best = null, source = '';
    cands.forEach(function (c) {
      var n = norm(c.text.replace(ELLIPSIS, '')), score = c.text.length > 200 ? 0 : 1;
      if (ttn && n && (ttn.indexOf(n) === 0 || n.indexOf(ttn.replace(ELLIPSIS, '')) >= 0 || ttn.indexOf(n.slice(0, 40)) >= 0)) score += 5;
      if (!best || score > best.score) best = { c: c, score: score };
    });
    var text = '', el = null, cutNote = false;
    if (best) {
      el = best.c.el; text = best.c.text; source = best.score >= 5 ? 'h1 (matches tab title)' : 'h1';
      if (best.score >= 5) {
        // the other sources must describe the same product (start the same way) before they can complete a cut title
        var base = norm(text.replace(ELLIPSIS, '')).slice(0, 30);
        var others = [cleanTitle(el.getAttribute('title') || ''), cleanTitle(stripShopee(tt)), cleanTitle(stripShopee((document.querySelector('meta[property="og:title"]') || {}).content || ''))]
          .concat(jsonLdName().map(cleanTitle)).filter(function (o) { return o && norm(o.replace(ELLIPSIS, '')).indexOf(base) >= 0; });
        var all2 = [text].concat(others);
        var pick = pickFullest(all2);
        if (isCut(text) || pick.length > text.length) { if (pick !== text) source = 'h1, completed from ' + (pick === cleanTitle(stripShopee(tt)) ? 'tab title' : 'other page data'); text = pick; }
        // an <h1> that is the tab title with a badge in front: use the cleaner tab title
        if (ttn && norm(text) !== ttn && norm(text).slice(-ttn.length) === ttn) { text = tt; source = 'tab title (h1 had extra text)'; }
        cutNote = isCut(text);
      }
    } else if (tt.length >= 10) { text = pickFullest([tt]) || tt; source = 'tab title'; }
    return { text: text, el: el, source: source, tabTitle: tt, cut: cutNote };
  }

  // Shop name: next to the "Lihat Toko" / "Kunjungi Toko" button, else a link to a shop page.
  var NOT_SHOP = /^(chat( sekarang)?|lihat toko|kunjungi toko|ikuti|mengikuti|online|aktif.*|penilaian.*|produk.*|performa.*|bergabung.*|persentase.*|waktu.*|pengikut.*|star\+?|mall|shopee mall)$/i;
  function findShopName() {
    var btns = all('button,a,div,span').filter(function (e) { return e.children.length === 0 && /^(lihat toko|kunjungi toko|view shop|visit shop)$/i.test(clean(e.textContent)); });
    for (var i = 0; i < btns.length; i++) {
      var box = btns[i];
      for (var up = 0; up < 6 && box.parentElement; up++) {
        box = box.parentElement;
        var lines = String(box.innerText || '').split('\n').map(clean).filter(Boolean);
        for (var j = 0; j < lines.length; j++) {
          if (lines[j].length >= 2 && lines[j].length <= 60 && !NOT_SHOP.test(lines[j]) && !/^\d/.test(lines[j]) && !/^rp/i.test(lines[j])) return lines[j];
        }
      }
    }
    var links = all('a[href]').filter(function (a) { return /\/shop\/\d+|^\/[A-Za-z0-9_.\-]+$/.test(a.getAttribute('href') || '') && clean(a.textContent).length >= 2 && clean(a.textContent).length <= 60; });
    for (var k = 0; k < links.length; k++) { var t = clean(links[k].textContent); if (!NOT_SHOP.test(t) && !/^rp/i.test(t)) return t; }
    return '';
  }

  // ---------- the gallery ----------
  // Main image = the largest Shopee image on the left, level with the title. The thumbnail strip is
  // the row of small images directly UNDER the main image; its container is found from the thumbnails
  // that are visible, so hidden slides of the same strip are included but nothing else on the page is
  // (no reviews, no shade buttons, no "you may also like"). Thumbnails with a text label are ignored.
  function lca(nodes) {
    var n = nodes[0];
    while (n && !nodes.every(function (x) { return n.contains(x); })) n = n.parentElement;
    return n;
  }
  function readGallery(titleEl) {
    var info = { mainFound: false, visibleThumbs: 0, thumbs: 0, skippedLabelled: 0, method: '', over9: false };
    var tr = titleEl ? rectOf(titleEl) : null;
    var els = cdnEls(document);
    var main = null, mainArea = 0, mr = null;
    els.forEach(function (e) {
      var r = rectOf(e);
      if (r.w < 250 || r.h < 250) return;
      if (tr) {
        if (r.l > tr.l + 20) return;                       // must be on the left of the title
        if (r.t > tr.b + 40 || r.b < tr.t - 40) return;    // and level with it (not a photo further down the page)
      }
      if (r.w * r.h > mainArea) { main = e; mainArea = r.w * r.h; mr = r; }
    });
    var urls = [];
    function add(el) {
      var full = PDP.fullImageUrl(elUrl(el));
      if (full && !urls.some(function (x) { return PDP.imgKey(x) === PDP.imgKey(full); })) urls.push(full);
    }
    if (!main) { info.method = 'no main image found'; return { urls: urls, info: info, mr: null, band: null, visEls: [] }; }
    info.mainFound = true; info.method = 'main image + the thumbnail row under it';

    function labelled(e) {
      var holder = e.closest('button,[role=button],label,[role=option],li');
      return !!(holder && clean(holder.textContent).length > 0);
    }
    function isThumb(e) {
      if (e === main) return false;
      var r = rectOf(e);
      return r.w >= 20 && r.h >= 20 && r.w < 250 && r.h < 250;
    }
    // thumbnails that are visible directly under the main image (same width as the main image)
    var vis = els.filter(function (e) {
      if (!isThumb(e)) return false;
      var r = rectOf(e);
      return r.t >= mr.b - 6 && r.t <= mr.b + 200 && r.l >= mr.l - 15 && r.l <= mr.r + 15;
    });
    info.visibleThumbs = vis.length;
    var band = null;
    if (vis.length) { var rs = vis.map(rectOf); band = { t: Math.min.apply(null, rs.map(function (r) { return r.t; })), b: Math.max.apply(null, rs.map(function (r) { return r.b; })), r: Math.max.apply(null, rs.map(function (r) { return r.r; })) }; }
    var strip = [];
    if (vis.length >= 2) {
      var box = lca(vis);
      if (box && !(titleEl && box.contains(titleEl))) {
        var inside = cdnEls(box).filter(isThumb);
        if (inside.length <= 15) strip = inside;
      }
    }
    if (!strip.length) strip = vis;
    strip.forEach(function (e) { if (labelled(e)) info.skippedLabelled++; else add(e); });
    if (!urls.length) add(main);                           // at least the big image
    info.thumbs = urls.length;
    info.over9 = urls.length > 9;
    return { urls: urls, info: info, mr: mr, band: band, visEls: vis };
  }

  // The thumbnail strip shows 5 at a time; the others sit behind the ">" arrow (and may be removed from the page
  // while hidden). Click the arrow step by step and collect every thumbnail seen, in order.
  var galCache = {};   // itemId -> all gallery URLs seen while clicking through
  function unionInto(list, more) { more.forEach(function (u) { if (!list.some(function (x) { return PDP.imgKey(x) === PDP.imgKey(u); })) list.push(u); }); return list; }
  var ARROWISH = /next|right|arrow|chevron|forward|carousel/i;
  function findNextArrow(mr, band) {
    if (!band) return null;
    var c = all('button,[role=button],svg,div,span,i,a').map(function (e) {
      return (e.tagName.toLowerCase() === 'svg' && e.parentElement && e.parentElement.closest('button,[role=button]')) || e;
    }).filter(function (e, i, a) { return a.indexOf(e) === i; }).filter(function (e) {
      if (e.disabled || e.getAttribute('aria-disabled') === 'true') return false;
      if (clean(e.textContent).length > 0 || cdnEls(e).length > 0) return false;
      var r = rectOf(e);
      if (r.w < 12 || r.h < 12 || r.w > 70 || r.h > 70) return false;
      var cy = (r.t + r.b) / 2;
      if (cy < band.t - 20 || cy > band.b + 20) return false;           // level with the thumbnail row
      if (!(r.r >= band.r - 80 && r.l <= band.r + 120 && r.l > mr.l + mr.w * 0.4)) return false;    // at its right end
      var cs = getComputedStyle(e);
      if (cs.backgroundImage !== 'none' || cs.visibility === 'hidden' || cs.display === 'none' || cs.pointerEvents === 'none' || parseFloat(cs.opacity) === 0) return false;
      var named = e.tagName.toLowerCase() === 'svg' || !!e.querySelector('svg') || ARROWISH.test((e.getAttribute('aria-label') || '') + ' ' + (typeof e.className === 'string' ? e.className : ''));
      return named || cs.cursor === 'pointer';
    });
    // nested matches: keep the innermost, then the right-most
    c = c.filter(function (e) { return !c.some(function (o) { return o !== e && e.contains(o); }); });
    c.sort(function (a, b) { return rectOf(b).l - rectOf(a).l; });
    return c[0] || null;
  }
  // Real-looking click: Shopee's carousel may listen for mouse/pointer events, not only "click".
  function press(el) {
    ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(function (type) {
      var C = type.indexOf('pointer') === 0 && window.PointerEvent ? PointerEvent : MouseEvent;
      el.dispatchEvent(new C(type, { bubbles: true, cancelable: true, view: window, button: 0 }));
    });
    el.click();
  }
  function describe(el) { return el.tagName + '.' + String(typeof el.className === 'string' ? el.className : '').slice(0, 40) + ' ' + (el.getAttribute('aria-label') || ''); }

  // ---- Method 1: Shopee's full-screen gallery. All thumbnails are drawn together there.
  function findModal() {
    var W = window.innerWidth, H = window.innerHeight, best = null;
    all('div,section,dialog').forEach(function (e) {
      var r = rectOf(e);
      if (r.w < W * 0.8 || r.h < H * 0.8) return;
      if (getComputedStyle(e).position !== 'fixed') return;
      var n = cdnEls(e).length;
      if (n >= 3 && (!best || n > best.n)) best = { el: e, n: n };
    });
    return best ? best.el : null;
  }
  // The thumbnails of the full-screen gallery = the group of small pictures that share one container (the grid).
  // Pictures elsewhere in the layer (and everything behind it: reviews, variant icons) are ignored.
  function modalThumbs(modal) {
    var els = cdnEls(modal), bigEl = null, big = 0;
    els.forEach(function (e) { var r = rectOf(e); if (r.w * r.h > big) { big = r.w * r.h; bigEl = e; } });
    var small = els.filter(function (e) {
      var r = rectOf(e);
      return e !== bigEl && r.w >= 20 && r.h >= 20 && r.w < 250 && r.h < 250;
    });
    if (!small.length) return [];
    // the container (up to 4 levels up) that holds the most small pictures and not the big one
    var best = null, counts = new Map();
    small.forEach(function (e) {
      var n = e.parentElement;
      for (var d = 0; n && n !== modal.parentElement && d < 5; d++, n = n.parentElement) {
        if (bigEl && n.contains(bigEl)) break;
        counts.set(n, (counts.get(n) || 0) + 1);
      }
    });
    counts.forEach(function (c, n) { if (!best || c > best.c || (c === best.c && n.contains(best.n))) best = { n: n, c: c }; });
    var urls = [];
    small.forEach(function (e) {
      if (best && !best.n.contains(e)) return;
      var u = PDP.fullImageUrl(elUrl(e));
      if (u && !urls.some(function (x) { return PDP.imgKey(x) === PDP.imgKey(u); })) urls.push(u);
    });
    return urls;
  }
  function pressKey(key, code) {
    ['keydown', 'keyup'].forEach(function (t) {
      [document.activeElement || document.body, document, window].forEach(function (target) {
        var ev = new KeyboardEvent(t, { key: key, code: code, bubbles: true, cancelable: true });
        try { Object.defineProperty(ev, 'keyCode', { get: function () { return 27; } }); Object.defineProperty(ev, 'which', { get: function () { return 27; } }); } catch (e) { /* read-only: fine */ }
        target.dispatchEvent(ev);
      });
    });
  }
  async function closeModal(modal) {
    pressKey('Escape', 'Escape');                                       // 1. Escape
    await sleep(250);
    if (!findModal()) return 'Escape';
    var m = findModal() || modal, mr2 = rectOf(m);
    var xs = all('button,[role=button],svg,div,span,i', m).map(function (e) {
      return (e.tagName.toLowerCase() === 'svg' && e.parentElement && e.parentElement.closest('button,[role=button]')) || e;
    }).filter(function (e) {
      var r = rectOf(e), t = clean(e.textContent);
      return r.w >= 14 && r.w <= 70 && r.h >= 14 && r.h <= 70 && cdnEls(e).length === 0 && t.length <= 1 && r.t < mr2.t + mr2.h * 0.25 && r.l > mr2.l + mr2.w * 0.6;
    });
    xs.sort(function (a, b) { var ra = rectOf(a), rb = rectOf(b); return (rb.l - rb.t) - (ra.l - ra.t); });   // top-right corner first
    if (xs[0]) { press(xs[0]); await sleep(250); if (!findModal()) return 'close button'; }
    var spot = document.elementFromPoint(6, 6);                         // 3. the dark backdrop
    if (spot) { press(spot); await sleep(250); if (!findModal()) return 'backdrop'; }
    return null;
  }
  async function readLightbox(g) {
    var res = { opened: false, thumbs: 0, closedBy: null };
    var main = null, area = 0;
    cdnEls(document).forEach(function (e) { var r = rectOf(e); if (g.mr && Math.abs(r.l - g.mr.l) < 3 && Math.abs(r.t - g.mr.t) < 3 && r.w * r.h > area) { main = e; area = r.w * r.h; } });
    if (!main) return { res: res, urls: [] };
    press(main);
    await sleep(450);
    var modal = findModal();
    if (!modal) { await sleep(450); modal = findModal(); }             // slow computer: one more look
    var urls = [];
    if (modal) {
      res.opened = true;
      urls = modalThumbs(modal);
      res.thumbs = urls.length;
      res.closedBy = await closeModal(modal);
      await sleep(150);
    }
    return { res: res, urls: urls };
  }

  // Collect EVERY gallery picture. Shopee draws only 5 thumbnails at a time in the normal view, so:
  //  Method 1: open the full-screen gallery (all thumbnails at once), read them, close it again.
  //  Method 2: click the ">" arrow, wait 400 ms, add new pictures to a Set; repeat until two clicks add nothing.
  //  Method 3 (last resort): click the right-most visible thumbnail so the strip slides along.
  var apiGallery = {};   // itemId -> pictures listed in Shopee's own data (only used when it agrees with the page)
  async function expandGallery() {
    var ids = PDP.parseProductUrl(location.href);
    var out = { clicks: 0, arrowFound: false, method: 'none', total: 0, waitedForGallery: 0, lightbox: null };
    var g = readGallery(findTitle().el);
    for (var w = 0; w < 10 && !(g.mr && g.urls.length); w++) {     // page still drawing: wait up to 3 s
      await sleep(300); out.waitedForGallery++; g = readGallery(findTitle().el);
    }
    if (!g.mr) return out;
    var seen = new Set(), order = [];
    function addAll(urls) {
      var added = 0;
      urls.forEach(function (u) { var k = PDP.imgKey(u); if (!seen.has(k)) { seen.add(k); order.push(u); added++; } });
      return added;
    }
    var initial = g.urls.slice();
    addAll(initial);

    // Method 1
    try {
      var lb = await readLightbox(g);
      out.lightbox = lb.res;
      if (lb.urls.length >= initial.length) {          // the full-screen list is the complete, ordered one
        order = []; seen = new Set(); addAll(lb.urls); addAll(initial);
        out.method = 'lightbox';
      }
    } catch (e) { out.lightboxError = String(e); }

    var still = 0, i;
    if (out.method !== 'lightbox') {
      g = readGallery(findTitle().el) || g;
      addAll(g.urls);
      for (i = 0; i < 12; i++) {                                    // Method 2: the ">" arrow
        var arrow = findNextArrow(g.mr, g.band);
        if (!arrow) break;
        out.arrowFound = true; out.method = 'arrow'; out.clicked = describe(arrow);
        press(arrow); out.clicks++;
        await sleep(400);
        g = readGallery(findTitle().el);
        still = addAll(g.urls) ? 0 : still + 1;
        if (still >= 2 || !g.mr) break;
      }
      if (g.mr && !out.arrowFound && order.length >= 4) {           // Method 3: no arrow found
        out.method = 'thumbnail clicks'; still = 0;
        var firstEl = g.visEls[0] || null;
        for (i = 0; i < 12; i++) {
          var vs = (g.visEls || []).slice().sort(function (x, y) { return rectOf(y).l - rectOf(x).l; });
          if (!vs.length) { await sleep(300); g = readGallery(findTitle().el); vs = (g.visEls || []).slice(); if (!vs.length) break; }
          press(vs[0]); out.clicks++;
          await sleep(500);
          g = readGallery(findTitle().el);
          still = addAll(g.urls) ? 0 : still + 1;
          if (still >= 2 || !g.mr) break;
        }
        if (firstEl && document.contains(firstEl)) press(firstEl);  // put the big picture back to the first slide
      }
    }
    // Shopee's own list (when we got it) completes a short result, but only if it contains everything we saw
    var api = ids && apiGallery[ids.itemId];
    var apiKeys = api ? api.map(PDP.imgKey) : [];
    if (api && api.length > order.length && order.every(function (u) { return apiKeys.indexOf(PDP.imgKey(u)) >= 0; })) { order = api.slice(); out.apiCompleted = true; }
    out.total = order.length;
    if (ids) galCache[ids.itemId] = order;
    return out;
  }

  // ---------- the description ----------
  var DESC_HEAD = /^(deskripsi produk|product description)\s*:?$/i;
  var END_HEAD = /^(penilaian produk|product ratings|produk lainnya.*|produk serupa|.*mungkin juga suka|pilihan untuk kamu|produk terkait|you may also like|more from this shop|lainnya dari toko.*)$/i;
  function leaves(re, after) {
    return all('h1,h2,h3,h4,h5,div,span,p').filter(function (e) {
      if (e.children.length !== 0 || !re.test(clean(e.textContent))) return false;
      return !after || !!(after.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING);
    });
  }
  function findDescHeading() { var l = leaves(DESC_HEAD); return l.length ? l[l.length - 1] : null; }   // the last one: not a menu entry

  // what follows the "Deskripsi Produk" heading, up to the next section (ratings / more products)
  function readDescription(head) {
    var out = { text: '', images: [], found: false };
    if (!head) return out;
    out.found = true;
    var box = head;
    while (box.parentElement && !box.nextElementSibling && box.parentElement !== document.body) box = box.parentElement;
    var texts = [];
    var seen = {};
    var ends = leaves(END_HEAD, head);
    for (var sib = box.nextElementSibling; sib; sib = sib.nextElementSibling) {
      if (ends.some(function (l) { return sib.contains(l); })) break;
      texts.push(sib.innerText || '');
      (elUrl(sib) ? [sib] : []).concat(cdnEls(sib)).forEach(function (e) {   // the sibling can itself be the picture
        var r = rectOf(e), nw = e.naturalWidth || 0;
        if (r.w < 300 && nw < 600) return;                 // small pictures (icons, product cards) are not description banners
        var u = PDP.fullImageUrl(elUrl(e));
        var uk = u && PDP.imgKey(u);
        if (u && !seen[uk]) { seen[uk] = 1; out.images.push(u); }
      });
    }
    out.text = texts.join('\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, 8000);
    return out;
  }
  var descCache = {};   // itemId -> { text, images } kept after the description was seen once

  // Shopee only draws the description when you scroll to it. Scroll down in small steps until the
  // heading appears, walk through the description so its pictures load, then return to where you were.
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  var descJob = null;
  function loadDescription(needDesc) {
    if (descJob) return descJob;
    var ids = PDP.parseProductUrl(location.href);
    descJob = (async function () {
      var x0 = window.scrollX, y0 = window.scrollY, started = Date.now(), steps = 0, head = findDescHeading();
      var result = { found: false, steps: 0, gallery: null };
      try {
        try { result.gallery = lastGallery = await expandGallery(); } catch (e) { result.galleryError = String(e); }
        if (needDesc === false) { result.found = true; return result; }
        while (!head && steps < 16 && Date.now() - started < 9000) {
          window.scrollBy({ top: Math.round(window.innerHeight * 0.8), behavior: 'instant' });
          await sleep(380); steps++;
          head = findDescHeading();
        }
        if (head) {
          head.scrollIntoView({ block: 'start', behavior: 'instant' });
          await sleep(500);
          for (var i = 0; i < 14 && Date.now() - started < 16000; i++) {
            var endEl = leaves(END_HEAD, head)[0];
            if (endEl && endEl.getBoundingClientRect().top <= window.innerHeight + 10 && i > 0) break;   // next section is on screen: all of the description was seen
            if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4) break;
            window.scrollBy({ top: Math.round(window.innerHeight * 0.8), behavior: 'instant' });
            await sleep(420);
          }
          result.found = true;
          var final = readDescription(findDescHeading() || head);
          if (ids && (final.text || final.images.length)) descCache[ids.itemId] = { text: final.text, images: final.images };
        }
      } catch (e) { result.error = String(e); }
      finally { window.scrollTo({ left: x0, top: y0, behavior: 'instant' }); result.steps = steps; descJob = null; }
      return result;
    })();
    return descJob;
  }

  // ---------- price ----------
  // The selling price is the biggest "Rp…" text in the price area under the title; crossed-out prices
  // (old price) are ignored, and a range "Rp60.000 - Rp79.000" gives its lowest value.
  var PRICE_ONLY = /^Rp\s?\d[\d.]*(\s*[-–]\s*Rp\s?\d[\d.]*)?$/i;
  // numbers next to "terjual", ratings, reviews and stock are never prices: a price candidate must contain "Rp" and none of these words
  var NOT_PRICE_WORDS = /terjual|sold|penilaian|rating|ulasan|review|stok|stock|tersisa|dilihat|pengikut/i;
  function isPriceText(t) { return t.length <= 40 && /Rp/i.test(t) && !NOT_PRICE_WORDS.test(t) && PRICE_ONLY.test(t); }
  function amountsOf(t) {
    var out = [], re = /Rp\s?(\d{1,3}(?:\.\d{3})+|\d{4,})/g, m;
    while ((m = re.exec(t))) { var v = parseInt(m[1].replace(/\./g, ''), 10); if (v >= 1000) out.push(v); }
    return out;
  }
  function struck(el) {
    for (var n = el, i = 0; n && i < 4; n = n.parentElement, i++) {
      var d = getComputedStyle(n).textDecorationLine || '';
      if (d.indexOf('line-through') >= 0 || n.tagName === 'DEL' || n.tagName === 'S') return true;
    }
    return false;
  }
  var lastPriceRect = null;      // where the price sits: the shade buttons are always below it
  function readPrice(titleEl) {
    if (!titleEl) return null;
    var tr = rectOf(titleEl), best = null, n = 0;
    lastPriceRect = null;
    all('div,span,p,b,strong,h2,h3').forEach(function (e) {
      var t = clean(e.textContent);
      if (!isPriceText(t)) return;
      if (Array.prototype.some.call(e.children, function (c) { return isPriceText(clean(c.textContent)); })) return;   // take the innermost one
      var r = rectOf(e);
      if (r.w === 0 || r.h === 0) return;
      if (r.t < tr.b - 5 || r.t > tr.b + 500 || r.l < tr.l - 20) return;
      if (struck(e)) return;
      var a = amountsOf(t); if (!a.length) return;
      var lo = Math.min.apply(null, a); if (lo < 1000 || lo > 100000000) return;       // not a believable retail price
      n++;
      var fs = parseFloat(getComputedStyle(e).fontSize) || 0;
      if (!best || fs > best.fs + 0.5) best = { fs: fs, v: lo, r: r };
    });
    if (best) lastPriceRect = best.r;
    return best ? best.v : null;
  }

  // ---------- variants / shades ----------
  // Option buttons between the price and the "Kuantitas" line, grouped by the box that holds them.
  var NOT_VARIANT = /^(klaim|ubah|lihat.*|pilih|chat.*|ikuti.*|beli.*|tambah.*|masukkan.*|keranjang.*|simpan|bagikan|\+|-|\d+|kuantitas|selengkapnya|lebih banyak|tutup|ok)$/i;
  // text that can never be a shade: ratings, sold counts, stock, shipping, vouchers, cart / buy buttons, quantity
  var JUNK_VARIANT_WORDS = /rating|penilaian|ulasan|review|terjual|\bsold\b|stok|stock|tersisa|sisa\s*\d|voucher|ongkir|pengiriman|gratis|garansi|masukkan|keranjang|beli\s*sekarang|kuantitas|quantity|\bcod\b|favorit|bagikan|dilaporkan|laporkan|\brp\s?\d/i;
  var JUNK_VARIANT_NUMBER = /^(\d[.,]\d{1,2}\s*(k|rb|jt)?|\d+([.,]\d+)?\s*(k|rb|jt|ribu)\+?|\d+\+)$/i;     // 4.9, 4,9k, 10RB+, 500+
  function isJunkVariant(t) { t = clean(t); return !t || NOT_VARIANT.test(t) || JUNK_VARIANT_WORDS.test(t) || JUNK_VARIANT_NUMBER.test(t); }
  function readVariants(titleEl) {
    var res = { names: [], groups: 0, qtyFound: false };
    if (!titleEl) return res;
    var tr = rectOf(titleEl);
    var qty = leaves(/^(kuantitas|quantity|jumlah)$/i).filter(function (e) { var r = rectOf(e); return r.l >= tr.l - 20 && r.t > tr.b; })[0];
    res.qtyFound = !!qty;
    var qr = qty ? rectOf(qty) : null;
    var pr = lastPriceRect;     // only buttons BELOW the price count: the rating / sold line sits between the title and the price
    var btns = all('button,[role=button],[role=radio],label').filter(function (e) {
      var t = clean(e.textContent);
      var al = clean(e.getAttribute('aria-label') || '');
      if (t.length < 1 || t.length > 60 || isJunkVariant(t) || (al && isJunkVariant(al))) return false;
      if (e.closest && e.closest('input,[type=number],[class*=quantity],[class*=Quantity]')) return false;
      var r = rectOf(e);
      if (r.w === 0 || r.h === 0 || r.l < tr.l - 20 || r.t < tr.b) return false;
      if (pr && r.t < pr.b - 2) return false;
      if (qr ? (r.b > qr.t + 4 || r.t < qr.t - 600) : r.t > tr.b + 700) return false;
      // a button that holds other buttons is a wrapper, not an option
      return !e.querySelector('button,[role=button],[role=radio]');
    });
    var groups = [];
    btns.forEach(function (b) {
      var g = groups.filter(function (x) { return x.parent === b.parentElement; })[0];
      if (!g) { g = { parent: b.parentElement, items: [] }; groups.push(g); }
      g.items.push(b);
    });
    groups = groups.filter(function (g) { return g.items.length >= 2; });
    // one group can be split over several boxes (one per row of options): merge neighbours that share a grandparent
    var merged = [];
    groups.forEach(function (g) {
      var gp = g.parent && g.parent.parentElement;
      var m = merged.filter(function (x) { return x.gp === gp && gp; })[0];
      if (m) m.items = m.items.concat(g.items); else merged.push({ gp: gp, items: g.items.slice() });
    });
    res.groups = merged.length;
    merged.forEach(function (g) {
      g.items.forEach(function (b) {
        var name = clean(b.getAttribute('aria-label') || b.textContent);
        if (name && !isJunkVariant(name) && res.names.indexOf(name) < 0) res.names.push(name);
      });
    });
    return res;
  }

  function readVisiblePage() {
    var title = findTitle();
    var gal = readGallery(title.el);
    var ids0 = PDP.parseProductUrl(location.href);
    if (ids0 && galCache[ids0.itemId]) gal.urls = unionInto(galCache[ids0.itemId].slice(), gal.urls);   // all slides collected by clicking the arrow
    var head = findDescHeading();
    var d = readDescription(head);
    var cached = null;
    var ids = PDP.parseProductUrl(location.href);
    if (ids && descCache[ids.itemId]) cached = descCache[ids.itemId];
    if (!d.text && cached) d = { text: cached.text, images: cached.images, found: true };
    var price = readPrice(title.el);
    var vr = readVariants(title.el);
    var shopName = findShopName();
    lastDom = { titleSource: title.source, tabTitle: title.tabTitle.slice(0, 120), h1Count: all('h1').length, gallery: gal.info,
      shopFound: !!shopName, priceFound: !!price, descriptionFound: d.found, descriptionChars: d.text.length, descriptionImages: d.images.length,
      galleryArrow: lastGallery,
      variants: { found: vr.names.length, groups: vr.groups, quantityLabelFound: vr.qtyFound } };
    return {
      title: title.text, pageTitle: title.text, images: gal.urls, descImages: d.images, price: price, priceBefore: null, description: d.text, variants: vr.names,
      brand: '', shopName: shopName, isOfficial: /official/i.test(shopName), rating: null, ratingCount: null, sold: null, netto: null
    };
  }

  function withInference(rec) {
    // shades vs bundles/promo packs; shade names found in the description text are added too (always from the raw list: safe to repeat)
    if (!rec.variantsRaw) rec.variantsRaw = (rec.variants || []).slice();
    rec.variantsRaw = rec.variantsRaw.filter(function (n) { return !isJunkVariant(n); });     // also cleans names that came from Shopee's data
    var sv = PDP.splitVariants(rec.variantsRaw, rec.description);
    rec.variants = sv.shades; rec.shadesFromDescription = sv.fromDescription;
    // brand / netto / category are read from Shopee's FULL title; the Product name field then gets the clean core name
    if (!rec.fullTitle) rec.fullTitle = rec.title; else rec.title = rec.fullTitle;
    var f = PDP.inferFields(rec);
    rec.brand = f.brand;
    rec.netto = f.netto;
    rec.suggestedCategory = f.suggestedCategory;
    rec.inferred = f.inferred;
    rec.title = PDP.cleanProductName(rec.fullTitle, rec.brand) || rec.fullTitle;
    return rec;
  }

  function getState() {
    var ids = PDP.parseProductUrl(location.href);
    if (!ids) return { status: 'not-product' };

    var base = { url: ids.url, shopId: ids.shopId, itemId: ids.itemId };
    var hit = store[ids.itemId];
    if (hit) {
      var rec = Object.assign({}, hit, base, { shopId: hit.shopId || ids.shopId, completeness: 'complete' });
      // Shopee's data is best; if the page title is clearly different, fill the shop name only when missing
      if (!rec.shopName) rec.shopName = findShopName();
      var dv = readVisiblePage();
      rec.descImages = dv.descImages;
      rec.pageTitle = dv.pageTitle || rec.pageTitle || '';        // the <h1> as the page shows it, kept apart from Shopee's data title
      if (!rec.description) rec.description = dv.description;
      if (!rec.variants || !rec.variants.length) rec.variants = dv.variants;
      if (!rec.price || rec.price < 1000) rec.price = dv.price;
      return { status: 'complete', record: withInference(rec) };
    }
    var vis = readVisiblePage();
    if (vis.title && vis.images.length) {
      return { status: 'partial', record: withInference(Object.assign({}, vis, base, { completeness: 'partial' })) };
    }
    // title found but no gallery yet: still let the user fix things by hand
    if (vis.title && lastDom && lastDom.gallery && !lastDom.gallery.mainFound) return { status: 'loading', title: vis.title };
    return { status: 'loading' };
  }

  chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg && msg.type === 'PDP_GET') {
      try { sendResponse(getState()); } catch (e) { sendResponse({ status: 'loading', error: String(e) }); }
    } else if (msg && msg.type === 'PDP_LOAD_DESC') {
      // scroll down to wake up the lazy-loaded description, read it, scroll back (answers when done)
      loadDescription(msg.needDesc).then(function (r) { sendResponse(r); }, function (e) { sendResponse({ found: false, error: String(e) }); });
      return true;
    } else if (msg && msg.type === 'PDP_DEBUG') {
      try {
        var ids = PDP.parseProductUrl(location.href);
        getState();
        sendResponse({ page: ids ? ids : null, haveShopeeData: !!(ids && store[ids.itemId]), capturedItems: Object.keys(store), apiPathsSeen: apiSeen, apiUnusable: apiFail, lastDomScan: lastDom });
      } catch (e) { sendResponse({ error: String(e) }); }
    }
  });
})();
