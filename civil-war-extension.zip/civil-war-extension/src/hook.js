/* Civil War - page hook (runs inside the Shopee page, before Shopee's own code).
 * It only LISTENS: when Shopee's page asks its own server for the product data, a copy of the
 * answer is passed to the extension. It never sends requests of its own and changes nothing on screen.
 */
(function () {
  'use strict';
  if (window.__pdpCaptureHook) return;
  window.__pdpCaptureHook = true;

  var WANTED = /\/api\/v4\/(pdp\/get_pc|pdp\/get|item\/get)(\?|$)/;

  // for the debug info only: remember which Shopee data addresses the page called (path only, no content)
  function seen(url) {
    try {
      var u = new URL(String(url), location.origin);
      if (u.pathname.indexOf('/api/') === 0) window.postMessage({ source: 'pdp-capture-hook', seen: u.pathname }, window.location.origin);
    } catch (e) { /* ignore */ }
  }

  function send(url, data) {
    try { window.postMessage({ source: 'pdp-capture-hook', url: String(url), data: data }, window.location.origin); } catch (e) { /* ignore */ }
  }

  // ----- fetch -----
  var origFetch = window.fetch;
  if (typeof origFetch === 'function') {
    window.fetch = function () {
      var promise = origFetch.apply(this, arguments);
      try {
        var a0 = arguments[0];
        var url = typeof a0 === 'string' ? a0 : (a0 && a0.url) || '';
        seen(url);
        if (WANTED.test(url)) {
          promise.then(function (res) {
            try { res.clone().json().then(function (d) { send(res.url || url, d); }).catch(function () {}); } catch (e) { /* ignore */ }
          }).catch(function () {});
        }
      } catch (e) { /* never break the page */ }
      return promise;
    };
  }

  // ----- XMLHttpRequest -----
  var XHR = window.XMLHttpRequest;
  if (XHR && XHR.prototype) {
    var origOpen = XHR.prototype.open;
    var origSend = XHR.prototype.send;
    XHR.prototype.open = function (method, url) {
      try { this.__pdpUrl = String(url); seen(url); } catch (e) { /* ignore */ }
      return origOpen.apply(this, arguments);
    };
    XHR.prototype.send = function () {
      try {
        var xhr = this;
        if (xhr.__pdpUrl && WANTED.test(xhr.__pdpUrl)) {
          xhr.addEventListener('load', function () {
            try {
              var d = null;
              if (xhr.responseType === 'json') d = xhr.response;
              else if (xhr.responseType === '' || xhr.responseType === 'text') d = JSON.parse(xhr.responseText);
              if (d) send(xhr.responseURL || xhr.__pdpUrl, d);
            } catch (e) { /* ignore */ }
          });
        }
      } catch (e) { /* never break the page */ }
      return origSend.apply(this, arguments);
    };
  }
})();
