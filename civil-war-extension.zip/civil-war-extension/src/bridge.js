/* Civil War - bridge between the website and this extension (runs only on the Civil War website, see manifest).
 * The website cannot hold your Gemini key, so for the two AI buttons (Claim matrix, Detect slides) it asks this
 * extension, in the same browser, to do the AI call with the key you already saved in the extension.
 * The key never leaves the extension; the website only receives the result.
 * Only these two request types are passed on. Everything else (saving, downloads, ...) is refused. */
(function () {
  'use strict';
  var ALLOWED = { PDP_CLAIM_MATRIX: 1, PDP_SLIDE_TYPES: 1 };
  function reply(o) { o.cwBridge = 'res'; window.postMessage(o, location.origin); }
  window.addEventListener('message', function (e) {
    if (e.source !== window || e.origin !== location.origin) return;     // only this page itself
    var d = e.data;
    if (!d || d.cwBridge !== 'req' || !d.id) return;
    if (d.kind === 'ping') { var v = ''; try { v = chrome.runtime.getManifest().version; } catch (x) {}
      reply({ id: d.id, pong: true, version: v }); return; }
    if (!d.msg || !ALLOWED[d.msg.type]) { reply({ id: d.id, res: { ok: false, error: 'This request is not allowed through the bridge.' } }); return; }
    try {
      chrome.runtime.sendMessage(d.msg).then(
        function (r) { reply({ id: d.id, res: r }); },
        function (err) { reply({ id: d.id, res: { ok: false, error: 'The extension did not answer: ' + String(err && err.message || err) + '. Reload this page and try again.' } }); });
    } catch (err) { reply({ id: d.id, res: { ok: false, error: 'The extension was updated. Reload this page (Cmd+Shift+R) and try again.' } }); }
  });
})();
