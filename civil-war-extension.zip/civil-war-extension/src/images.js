/* Civil War - copies a product's banner pictures from Shopee into the shared Supabase storage (folder "banners").
 * Why: Shopee picture links can stop working, and the website cannot export "HD image" from other sites' pictures.
 * Each picture is saved once under its own Shopee picture id, so the same picture is never stored twice.
 * The product record keeps the original Shopee addresses and gets imageCopy = { pictureId: 1 }.
 * Runs only inside the extension (only it may read Shopee's picture server). Never deletes anything. */
(function (root) {
  'use strict';
  var BUCKET = 'banners', POOL = 3, MAX_BYTES = 12 * 1024 * 1024;

  function cfg() { return root.CW_CONFIG || {}; }
  function C() { return root.CWStoreCloud; }
  function isCopy(u) { return String(u || '').indexOf('/storage/v1/object/public/' + BUCKET + '/') >= 0; }

  async function upload(id, blob) {
    var c = cfg(), headers = { apikey: c.supabaseKey, 'Content-Type': blob.type || 'application/octet-stream' };
    if (/^eyJ/.test(c.supabaseKey || '')) headers.Authorization = 'Bearer ' + c.supabaseKey;   // older "anon" keys are JWTs
    var res = await fetch(c.supabaseUrl + '/storage/v1/object/' + BUCKET + '/file/' + encodeURIComponent(id), { method: 'POST', headers: headers, body: blob });
    if (res.ok) return;
    var t = ''; try { t = await res.text(); } catch (e) { /* ignore */ }
    if (res.status === 409 || /Duplicate|already exists/i.test(t)) return;   // already copied before
    throw new Error('Picture storage error ' + res.status + ': ' + t.slice(0, 160));
  }

  async function copyOne(url) {
    var res = await fetch(url, { credentials: 'omit' });
    if (!res.ok) throw new Error('Shopee picture ' + res.status);
    var blob = await res.blob();
    if (!/^image\//.test(blob.type)) throw new Error('not a picture');
    if (blob.size > MAX_BYTES) throw new Error('picture too large');
    await upload(root.PDP.imgKey(url), blob);
  }

  // Copies every picture of the newest saved version of one product that is not copied yet.
  // onTick(doneCount, totalToCopy) is optional. Returns { total, already, copied, failed }.
  async function copyProduct(key, onTick) {
    var cl = C(); if (!cl) throw new Error('Shared database is not set up');
    var rows = await cl.raw.sb('GET', 'snapshots?select=data&product_key=eq.' + cl.raw.enc(key) + '&order=captured_at.desc,id.desc&limit=1');
    if (!rows || !rows.length) throw new Error('Product not found');
    var rec = rows[0].data, have = rec.imageCopy || {}, seen = {}, urls = [];
    (rec.images || []).concat(rec.descImages || []).forEach(function (u) { var id = root.PDP.imgKey(u); if (u && !seen[id]) { seen[id] = 1; urls.push(u); } });
    var todo = urls.filter(function (u) { return !have[root.PDP.imgKey(u)]; });
    var done = {}, failed = 0, n = 0, next = 0;
    async function worker() {
      while (next < todo.length) {
        var u = todo[next++];
        try { await copyOne(u); done[root.PDP.imgKey(u)] = 1; } catch (e) { failed++; }
        n++; if (onTick) onTick(n, todo.length);
      }
    }
    var pool = []; for (var i = 0; i < Math.min(POOL, todo.length); i++) pool.push(worker());
    await Promise.all(pool);
    var copied = Object.keys(done).length;
    if (copied) await cl.updateLatest(key, function (r) { r.imageCopy = Object.assign({}, r.imageCopy || {}, done); });
    return { total: urls.length, already: urls.length - todo.length, copied: copied, failed: failed };
  }

  // Which products still have pictures that are not copied (from data returned by CWStoreCloud.load()).
  function pending(snapshots) {
    var latest = {};
    snapshots.forEach(function (s) { var k = root.PDP.recordKey(s); if (!latest[k] || s.capturedAt > latest[k].capturedAt) latest[k] = s; });
    return Object.keys(latest).filter(function (k) {
      var s = latest[k];
      return (s.images || []).concat(s.descImages || []).some(function (u) { return u && !isCopy(u); });
    });
  }

  root.CWImages = { copyProduct: copyProduct, pending: pending };
})(typeof self !== 'undefined' ? self : this);
