/* Civil War - background worker: saves records and downloads the package. */
importScripts('shared.js', 'config.js', 'store.js');

// Clicking the toolbar icon opens the docked side panel (it stays open while you browse).
function openPanelOnIconClick() {
  try { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {}); } catch (e) { /* older Chrome */ }
}
openPanelOnIconClick();
chrome.runtime.onInstalled.addListener(openPanelOnIconClick);

async function getAll() { return CWStore.load(); }

// Start one download. If Chrome refuses the file name (special characters on some systems),
// try once more with a plain-ASCII version of the same path.
async function startDownload(url, filename) {
  try {
    return await chrome.downloads.download({ url: url, filename: filename, conflictAction: 'uniquify', saveAs: false });
  } catch (e) {
    if (/invalid filename/i.test(String(e && e.message || e)) && PDP.asciiPath(filename) !== filename) {
      return await chrome.downloads.download({ url: url, filename: PDP.asciiPath(filename), conflictAction: 'uniquify', saveAs: false });
    }
    throw e;
  }
}

// Build and start the downloads for one record. Returns what happened.
async function downloadPackage(rec) {
  var folder = PDP.folderPath(rec);
  var result = { folder: folder, images: 0, imagesFailed: 0, texts: 0, textsFailed: 0, firstError: '' };

  for (var i = 0; i < rec.images.length; i++) {
    try {
      await startDownload(rec.images[i], folder + '/' + PDP.pad2(i + 1) + '.jpg');
      result.images++;
    } catch (e) { result.imagesFailed++; if (!result.firstError) result.firstError = String(e && e.message || e); }
  }

  // images from the description: desc-01.jpg, desc-02.jpg ...
  var di = rec.descImages || [];
  for (var j = 0; j < di.length; j++) {
    try {
      await startDownload(di[j], folder + '/desc-' + PDP.pad2(j + 1) + '.jpg');
      result.images++;
    } catch (e) { result.imagesFailed++; if (!result.firstError) result.firstError = String(e && e.message || e); }
  }

  var files = [
    { name: 'info.txt', mime: 'text/plain', body: PDP.buildInfoTxt(rec) },
    { name: 'data.json', mime: 'application/json', body: JSON.stringify(Object.assign({ schema: 'pdp-capture/1', key: PDP.recordKey(rec) }, rec), null, 2) }
  ];
  for (var f = 0; f < files.length; f++) {
    try {
      await startDownload('data:' + files[f].mime + ';charset=utf-8,' + encodeURIComponent(files[f].body), folder + '/' + files[f].name);
      result.texts++;
    } catch (e) { result.textsFailed++; if (!result.firstError) result.firstError = String(e && e.message || e); }
  }
  return result;
}

async function handleSave(msg) {
  var rec = msg.record;
  if (!rec || !rec.title || !Array.isArray(rec.images)) throw new Error('Nothing to save');
  var hint = await CWStore.hints(null);
  var settings = hint.settings || {};
  // reuse the spelling of a category that already exists ("setting spray" -> "Setting Spray")
  var cat = String(rec.category || '').trim();
  hint.categories.forEach(function (c) { if (cat && c.toLowerCase() === cat.toLowerCase()) cat = c; });
  delete rec.suggestedCategory; delete rec.suggestedMainCategory; delete rec.inferred;
  delete rec.variantsRaw; delete rec.shadesFromDescription;
  rec = Object.assign({}, rec, {
    category: cat,
    mainCategory: PDP.cleanMainCategory(rec.mainCategory) || PDP.mainCategoryFor(cat),
    capturedAt: new Date().toISOString(),
    savedBy: settings.userName || ''
  });
  await CWStore.addSnapshot(rec, { lastCategory: rec.category, download: !!msg.download });

  var out = { ok: true, key: PDP.recordKey(rec), folder: PDP.folderPath(rec), download: null };
  if (msg.download) out.download = await downloadPackage(rec);
  return out;
}

async function handleRedownload(msg) {
  var data = await getAll();
  var latest = null;
  data.snapshots.forEach(function (s) {
    if (PDP.recordKey(s) === msg.key && (!latest || s.capturedAt > latest.capturedAt)) latest = s;
  });
  if (!latest) throw new Error('Product not found in your library');
  return { ok: true, download: await downloadPackage(latest) };
}

// ---------- Phase 2: AI reading with Gemini ----------
// Runs here (not in the side panel) so that fetching Shopee's pictures is never blocked by CORS.
// Only public banners, description pictures and description text are sent. Team notes never are.
var AI_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.6-flash'];   // the only models the side panel can choose
var AI_DEFAULT_MODEL = 'gemini-3.5-flash-lite';
function endpointFor(model) { return 'https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent'; }
var AI_MIME = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'];   // what Gemini reads
var AI_MAX_IMAGES = 14;                      // unique pictures per single request: main gallery first, then description
var AI_MAX_WIDTH = 800;                      // pictures are shrunk to this width before sending (height follows the ratio)
var AI_JPEG_QUALITY = 0.8;                   // and re-encoded as JPEG at this quality; text stays readable at this size
var AI_MAX_IMAGE_BYTES = 4 * 1024 * 1024;    // one picture
var AI_MAX_TOTAL_BYTES = 12 * 1024 * 1024;   // all pictures together (Gemini allows 20 MB per request, base64 adds about a third)

function bytesToBase64(buf) {
  var bytes = new Uint8Array(buf), s = '', CH = 0x8000;
  for (var i = 0; i < bytes.length; i += CH) s += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  return btoa(s);
}

// Shrink a picture to AI_MAX_WIDTH and re-encode it as JPEG (quality AI_JPEG_QUALITY). A service worker has no
// <img> or <canvas>, so this uses createImageBitmap and OffscreenCanvas. Returns null if the browser cannot decode it.
async function shrinkImage(buf, mime) {
  try {
    var bmp = await createImageBitmap(new Blob([buf], { type: mime }));
    var scale = Math.min(1, AI_MAX_WIDTH / bmp.width);
    var w = Math.max(1, Math.round(bmp.width * scale)), h = Math.max(1, Math.round(bmp.height * scale));
    var canvas = new OffscreenCanvas(w, h);
    var ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';                 // transparent areas become white, not black, in JPEG
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bmp, 0, 0, w, h);
    if (bmp.close) bmp.close();
    var out = await canvas.convertToBlob({ type: 'image/jpeg', quality: AI_JPEG_QUALITY });
    var ob = await out.arrayBuffer();
    return { mime: 'image/jpeg', bytes: ob.byteLength, data: bytesToBase64(ob), width: w, height: h };
  } catch (e) {
    return null;
  }
}

async function fetchImagePart(url) {
  var res = await fetch(url, { credentials: 'omit' });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  var type = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (!/^image\//.test(type)) type = 'image/jpeg';
  var buf = await res.arrayBuffer();
  var small = await shrinkImage(buf, type);
  if (small) return small;                     // resized, sent as JPEG
  return { mime: type, bytes: buf.byteLength, data: bytesToBase64(buf) };   // could not decode: send the original
}

// Build the picture list: the same picture (same Shopee picture id) is kept once, even when it appears in both
// the main gallery and the description. Then keep the first AI_MAX_IMAGES in order (gallery first) and fetch them in parallel.
async function collectImageParts(p, skipped) {
  var seen = {}, all = [];
  function addAll(list, prefix) {
    (list || []).forEach(function (u, i) {
      var k = PDP.imgKey(u);
      if (seen[k]) return;
      seen[k] = true;
      all.push({ url: u, label: prefix + ' ' + (i + 1) });
    });
  }
  addAll(p.images, 'Slide');
  addAll(p.descImages, 'Desc');
  all.slice(AI_MAX_IMAGES).forEach(function (j) { skipped.push(j.label + ' (over the ' + AI_MAX_IMAGES + '-picture limit)'); });
  var jobs = all.slice(0, AI_MAX_IMAGES);
  var fetched = await Promise.all(jobs.map(function (j) {
    return fetchImagePart(j.url).catch(function (e) { return { error: String(e && e.message || e) }; });
  }));
  var parts = [], total = 0, count = 0;
  fetched.forEach(function (img, k) {
    var label = jobs[k].label;
    if (!img || img.error) { skipped.push(label + ' (could not load' + (img && img.error ? ': ' + img.error : '') + ')'); return; }
    if (AI_MIME.indexOf(img.mime) < 0) { skipped.push(label + ' (' + img.mime + ' not supported)'); return; }
    if (count >= AI_MAX_IMAGES || img.bytes > AI_MAX_IMAGE_BYTES || total + img.bytes > AI_MAX_TOTAL_BYTES) {
      skipped.push(label + ' (over the size or count limit)'); return;
    }
    total += img.bytes; count++;
    parts.push({ text: label + ':' }, { inline_data: { mime_type: img.mime, data: img.data } });
  });
  return { parts: parts, count: count };
}

// text that is never a shade (same idea as the page scraper; kept here too because the AI answer is not trusted blindly)
var JUNK_SHADE_WORDS = /rating|penilaian|ulasan|review|terjual|\bsold\b|stok|stock|tersisa|sisa\s*\d|voucher|ongkir|pengiriman|gratis|garansi|masukkan|keranjang|beli\s*sekarang|kuantitas|quantity|\bcod\b|\brp\s?\d/i;
var JUNK_SHADE_NUMBER = /^(\d[.,]\d{1,2}\s*(k|rb|jt)?|\d+([.,]\d+)?\s*(k|rb|jt|ribu)\+?|\d+\+)$/i;
function isJunkShade(t) { t = String(t || '').replace(/\s+/g, ' ').trim(); return !t || JUNK_SHADE_WORDS.test(t) || JUNK_SHADE_NUMBER.test(t); }

function buildPrompt(p, hasImages) {
  var cand = (Array.isArray(p.shadeCandidates) ? p.shadeCandidates : []).map(function (x) { return String(x || '').slice(0, 60); }).filter(Boolean).slice(0, 60);
  return [
    'You are a Senior Beauty & Cosmetics Brand Researcher doing desk research on a competitor\'s Shopee product page.',
    '',
    'Product page title (the <h1>, exactly as the page shows it): ' + (p.pageTitle || p.title || '(unknown)'),
    'Shop name (seller): ' + (p.shopName || '(unknown)') + (p.isOfficial ? ' (Official Store)' : ''),
    'Product name now in the form: ' + (p.title || '(unknown)'),
    'Brand now in the form: ' + (p.brand || '(unknown)'),
    'Price text read from the page: ' + (p.priceText || '(none)'),
    'Option buttons read from the page (may include wrong items): ' + (cand.length ? cand.join(' | ') : '(none)'),
    'Category: ' + (p.category || '(unknown)'),
    'Main category chosen so far: ' + (p.mainCategory || '(unknown)'),
    '',
    hasImages
      ? 'Sources: the banner pictures labelled "Slide n" (main gallery, in slide order), the description pictures labelled "Desc n", and the text description below. Each picture follows its label.'
      : 'No pictures are supplied. Work from the text description below only.',
    '',
    'Description text:',
    p.description ? p.description : '(no description text)',
    '',
    'Rules:',
    '- Copy wording as it appears on the banners or in the text. Indonesian stays Indonesian, English stays English. Do not translate and do not invent anything.',
    '- If something is not there, use an empty string "" for text fields and [] for lists. Never guess.',
    '- Every item must say where it came from in "source": "Slide n", "Desc n" or "Description text".',
    '- Ignore prices, discounts, vouchers, free shipping, stock and seller promo lines.',
    '- Strict deduplication: never repeat the same or a nearly identical point twice within one list, even when the slides and the description word it differently. Keep the clearest wording once.',
    '',
    'Definitions. Keep Hero Claim, RTB and Key Ingredients apart:',
    '- heroClaims = HERO CLAIM = the PROMISE. ONLY functional benefits and sensory promises to the consumer. Examples: "Melembapkan & mengurangi kerutan bibir", "Intense hydration & non-sticky".',
    '  Do NOT put clinical test percentages (for example "97% agree...") or empty slogan filler (for example "FOR CLEAN ZZZLIP BREAK") here.',
    '- rtb = RTB = the PROOF. ONLY concrete proof that validates the claims. Three kinds:',
    '  1. Clinical, instrumental or consumer test stats. Examples: "97% agree brighter plumper lips in 14 days (based on 38 women)", "Dermatologically tested".',
    '  2. Applicator or packaging tech. Example: "Contour-fit applicator".',
    '  3. Safety or formulation certifications. Example: "0% Alcohol".',
    '  Do NOT repeat a hero claim here, do NOT list shade names (for example "Shades baru: ..."), and do NOT list active ingredients here.',
    '- keyIngredients = every active ingredient, once. If the banners or the description say what an ingredient does, write it as "Ingredient Name — specific function", for example "3% Vitamin C — mencerahkan bibir" or "Plump Peptide — membuat bibir tampak plumpy & mengurangi garis bibir". If no function is stated, write just the name.',
    '- Do NOT put marketing hype or sales figures into heroClaims or rtb. Leave out things like "1.000.000+ terjual", "Upgrade OOTD-mu", "Best seller", "Wajib punya".',
    '- A point is either a promise (heroClaims) or a proof (rtb), never both. Ingredients go only to keyIngredients.',
    '',
    'Product description:',
    '- productDescription = the OPENING product overview paragraph the seller wrote at the top of the description text: what the product is, its look, texture and result. Copy it as the seller wrote it, in the seller\'s own Indonesian or English, without translating and without shortening its meaning. Stop before the bullet lists and headings that follow it, such as Benefit, Manfaat, Cara Pakai, How to use, Ingredients, Komposisi, BPOM, shade lists or notes.',
    '- If the seller wrote no opening paragraph (the description starts straight with bullet points or headings), write a clean overview of 2 to 4 sentences in the seller\'s language, using only facts from the description text and banners. If there is nothing to base it on, use "".',
    '- Do not put benefits lists, usage steps, ingredient lists, prices or promo lines into productDescription.',
    '',
    'Classification:',
    '- mainCategory = exactly one of "Skincare" (skin treatment: cleanser, toner, serum, moisturizer, sunscreen, mask, lip balm), "Decorative" (makeup: base makeup, lip, eye, cheek, setting spray, tools) or "Personal Care" (body, hair, deodorant, fragrance). Decide from what the product is and does, not from the brand.',
    '- category = the specific product type in 1 to 3 English words, for example Cushion, Lip Serum, Sunscreen, Moisturizer, Body Lotion.',
    '',
    'Basics (name, brand, price, shades):',
    '- brand = the clean Brand Name only. Take it from the Official Store shop name when the shop is the brand\'s own store, otherwise from the leading brand word(s) in the page title. Never a shop description, a promo or a product type.',
    '- productName = the clean product name only: the page title without the brand, without promo or admin tags such as [PROMO], [COD], [BPOM], [READY], [FREE ...], without bundle or freebie noise (free gift, hadiah, bonus, paket hemat), without emojis, and without the size. Keep the real product line and variant words.',
    '- price = the retail selling price in rupiah as a whole number. It MUST come from a currency amount written with "Rp" (the "Price text read from the page" line, or "Rp" amounts in the description). NEVER use a sold count (for example 10RB+ Terjual, 10.000), a review or rating count, a stock number or a rating such as 4.9 as the price. For a range such as Rp34.155 - Rp45.000 use the lowest amount. If you cannot find an Rp amount, use null.',
    '- shades = ONLY the real product shades, colors or size variants a buyer can choose, in the seller\'s own spelling and order. Start from the option buttons above, remove anything that is not a shade or size (ratings such as 4,9k rating, "penilaian", "terjual", "stok", "tersisa", reviews, vouchers, shipping, Masukkan Keranjang, Beli Sekarang, quantity, store names), and add a shade only if it is clearly named in the description or on a shade banner. If there are no shades or sizes, use [].',
    '',
    'Return ONLY a JSON object (no markdown) with exactly this shape:',
    '{',
    '  "mainCategory": "Skincare, Decorative or Personal Care",',
    '  "category": "specific product type",',
    '  "brand": "clean brand name",',
    '  "productName": "clean product name without brand, promo tags or size",',
    '  "price": "whole rupiah number from an Rp amount, or null",',
    '  "shades": ["real shade, color or size name"],',
    '  "singleKeyMessage": "one sentence: the core positioning or tagline in the brand\'s tone",',
    '  "productDescription": "the opening product overview paragraph, in the seller\'s own wording and language",',
    '  "heroClaims": [{"text": "main functional or emotional promise, e.g. 12H Oil Control, Transferproof", "source": "Slide 1"}],',
    '  "rtb": [{"text": "a clinical test result, applicator technology or certification from the definitions above", "source": ""}],',
    '  "keyIngredients": [{"text": "Ingredient Name — specific function, or just the name if no function is stated", "source": ""}],',
    '  "texture": "e.g. Lightweight gel",',
    '  "finish": "e.g. Matte",',
    '  "targetSkin": "e.g. Oily & acne-prone skin",',
    '  "howToUse": [{"text": "one usage step", "source": ""}],',
    '  "audit": [{"claim": "each claim from the banners or the text", "banners": "Slide 2, Slide 4 or Not mentioned", "description": "Yes or Not mentioned"}]',
    '}',
    'The audit lists every claim found in either source. Use "Not mentioned" where the claim exists in only one source.'
  ].join('\n');
}

function cleanText(v, max) { return String(v === null || v === undefined ? '' : v).replace(/\s+/g, ' ').trim().slice(0, max || 300); }
function cleanList(arr) {
  return (Array.isArray(arr) ? arr : []).map(function (x) {
    var t = cleanText(x && x.text, 300), source = cleanText(x && x.source, 40);
    // if the model put a source tag at the end of the text ("... [Slide 1]"), move it to the source field
    var m = t.match(/^(.*?)\s*\[(Slide \d+|Desc \d+|Description text)\]$/i);
    if (m) { t = m[1].trim(); source = source || m[2]; }
    return t ? { text: t, source: source } : null;
  }).filter(Boolean).slice(0, 40);
}
// price: whole rupiah between 1.000 and 100.000.000, otherwise null (a sold count such as 10 or a rating such as 4.9 is far below 1.000)
function cleanPrice(v) {
  if (v === null || v === undefined || v === '') return null;
  var n = typeof v === 'number' ? v : parseInt(String(v).replace(/[^\d]/g, ''), 10);
  return isFinite(n) && n >= 1000 && n <= 100000000 ? Math.round(n) : null;
}
function cleanShades(arr) {
  var seen = {}, out = [];
  (Array.isArray(arr) ? arr : []).forEach(function (x) {
    var t = cleanText(typeof x === 'string' ? x : x && x.text, 60);
    if (!t || isJunkShade(t)) return;
    var k = t.toLowerCase();
    if (!seen[k]) { seen[k] = 1; out.push(t); }
  });
  return out.slice(0, 60);
}
// the AI's price is only kept when the same Rp amount really is written in the text we sent (never a sold or review count)
function priceSeenInText(price, text) {
  if (!price) return null;
  var re = /Rp\s?(\d{1,3}(?:[.,]\d{3})+|\d{4,})/gi, m;
  while ((m = re.exec(String(text || '')))) { if (parseInt(m[1].replace(/[.,]/g, ''), 10) === price) return price; }
  return null;
}
function normalizeAi(o) {
  o = o || {};
  var audit = (Array.isArray(o.audit) ? o.audit : []).map(function (a) {
    var c = cleanText(a && a.claim, 300);
    return c ? { claim: c, banners: cleanText(a.banners, 120) || 'Not mentioned', description: cleanText(a.description, 60) || 'Not mentioned' } : null;
  }).filter(Boolean).slice(0, 40);
  return {
    mainCategory: PDP.cleanMainCategory(o.mainCategory),
    category: cleanText(o.category, 40),
    brand: cleanText(o.brand, 40),
    productName: cleanText(o.productName, 140),
    price: cleanPrice(o.price),
    shades: cleanShades(o.shades),
    singleKeyMessage: cleanText(o.singleKeyMessage, 300),
    productDescription: cleanText(o.productDescription, 1500),
    heroClaims: cleanList(o.heroClaims),
    rtb: cleanList(o.rtb),
    keyIngredients: cleanList(o.keyIngredients),
    texture: cleanText(o.texture, 120),
    finish: cleanText(o.finish, 120),
    targetSkin: cleanText(o.targetSkin, 160),
    howToUse: cleanList(o.howToUse),
    audit: audit
  };
}

async function handleAiAnalyze(msg) {
  var got = await chrome.storage.local.get({ aiSettings: {} });
  var cfg = got.aiSettings || {};
  var key = String(cfg.apiKey || '').trim();
  if (!key) throw new Error('Paste your Gemini API key in AI Settings first');
  var p = msg.payload || {};
  var model = AI_MODELS.indexOf(p.model) >= 0 ? p.model : (AI_MODELS.indexOf(cfg.model) >= 0 ? cfg.model : AI_DEFAULT_MODEL);
  var useImages = cfg.includeImages !== false && p.includeImages !== false;
  var skipped = [], imagesSent = 0, parts = [];

  if (useImages) {
    var imgs = await collectImageParts(p, skipped);
    imagesSent = imgs.count;
    parts = imgs.parts;
  }
  parts.unshift({ text: buildPrompt(p, imagesSent > 0) });

  var body = {
    contents: [{ role: 'user', parts: parts }],
    generationConfig: {
      responseMimeType: 'application/json',   // JSON output only; no temperature or thinking settings (not used by 3.x models)
      maxOutputTokens: 8192
    }
  };

  var res = await fetch(endpointFor(model), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify(body)
  });
  var js = await res.json().catch(function () { return {}; });
  if (!res.ok) throw new Error((js.error && js.error.message) || ('Gemini answered HTTP ' + res.status));
  if (js.promptFeedback && js.promptFeedback.blockReason) throw new Error('Gemini did not accept the request (' + js.promptFeedback.blockReason + ')');
  var cand = js.candidates && js.candidates[0];
  var text = cand && cand.content && cand.content.parts ? cand.content.parts.map(function (x) { return x.text || ''; }).join('') : '';
  if (!text) throw new Error('Gemini sent no text (' + ((cand && cand.finishReason) || 'no reason given') + ')');
  var out;
  try { out = JSON.parse(text); }
  catch (e) { throw new Error('Gemini answer was cut or not valid JSON (' + ((cand && cand.finishReason) || 'unknown') + ')'); }

  var result = normalizeAi(out);
  result.price = priceSeenInText(result.price, (p.priceText || '') + ' ' + (p.description || ''));
  return {
    ok: true,
    result: result,
    meta: { model: model, analyzedAt: new Date().toISOString(), imagesSent: imagesSent, imagesSkipped: skipped }
  };
}

// ---------- Slide types: what each banner picture shows (for the Compare PDP filter) ----------
// Read on demand from the dashboard, never during save. Pictures are shrunk the same way as for the AI reading.
var SLIDE_TYPES = ['cover', 'hero', 'ingredients', 'shades', 'howto', 'other'];
async function handleSlideTypes(msg) {
  var got = await chrome.storage.local.get({ aiSettings: {} });
  var key = String((got.aiSettings || {}).apiKey || '').trim();
  if (!key) throw new Error('Paste your Gemini API key in AI Settings (side panel) first');
  var p = msg.payload || {}, skipped = [];
  var imgs = await collectImageParts({ images: p.images || [], descImages: p.descImages || [] }, skipped);
  if (!imgs.count) throw new Error('No pictures could be loaded for this product' + (skipped.length ? ' (' + skipped[0] + ')' : ''));
  var prompt =
    'You classify the banner pictures of a Shopee beauty product page. Each picture follows its label ("Slide n" = main gallery, "Desc n" = description picture).\n' +
    'For every picture choose exactly one type:\n' +
    '- cover: the first product shot or packshot with brand and name\n' +
    '- hero: the main promise or key claim of the product (big headline benefit)\n' +
    '- ingredients: shows active ingredients or the formula\n' +
    '- shades: shows shade, color or swatch options\n' +
    '- howto: shows how to use, steps or application\n' +
    '- other: anything else (texture, testimonials, test results, certificates, promo, store info)\n' +
    'Decide from what the picture mainly shows. Use only the labels given.\n' +
    'Return JSON only: {"slides":[{"label":"Slide 1","type":"cover"}]}';
  var res = await fetch(endpointFor(AI_DEFAULT_MODEL), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }].concat(imgs.parts) }], generationConfig: { responseMimeType: 'application/json', maxOutputTokens: 2048 } })
  });
  var js = await res.json().catch(function () { return {}; });
  if (!res.ok) throw new Error((js.error && js.error.message) || ('Gemini answered HTTP ' + res.status));
  if (js.promptFeedback && js.promptFeedback.blockReason) throw new Error('Gemini did not accept the request (' + js.promptFeedback.blockReason + ')');
  var cand = js.candidates && js.candidates[0];
  var out = cand && cand.content && cand.content.parts ? cand.content.parts.map(function (x) { return x.text || ''; }).join('') : '';
  if (!out) throw new Error('Gemini sent no text (' + ((cand && cand.finishReason) || 'no reason given') + ')');
  var data;
  try { data = JSON.parse(out); } catch (e) { throw new Error('Gemini answer was cut or not valid JSON'); }
  var types = {};
  (Array.isArray(data.slides) ? data.slides : []).forEach(function (s) {
    var label = String(s && s.label || '').trim(), t = String(s && s.type || '').toLowerCase().replace(/[^a-z]/g, '');
    if (t === 'ingredient') t = 'ingredients'; if (t === 'shade') t = 'shades'; if (t === 'howtouse') t = 'howto';
    if (/^(Slide|Desc) \d+$/.test(label) && SLIDE_TYPES.indexOf(t) >= 0) types[label] = t;
  });
  if (!Object.keys(types).length) throw new Error('Gemini did not return slide types. Try again');
  return { ok: true, types: types, skipped: skipped, at: new Date().toISOString() };
}

// ---------- Claim matrix: group the claims of 2 to 6 saved products (text only, no pictures) ----------
// The dashboard sends every claim line with an ID. Gemini answers with labels, and for each product the line ID plus the short
// phrase of that line that proves the claim. The phrase is checked against the original line here, so the matrix can never
// show wording the product did not use.
function normForMatch(t) { return String(t || '').toLowerCase().replace(/\s+/g, ' ').trim(); }

async function handleClaimMatrix(msg) {
  var got = await chrome.storage.local.get({ aiSettings: {} });
  var key = String((got.aiSettings || {}).apiKey || '').trim();
  if (!key) throw new Error('Paste your Gemini API key in AI Settings (side panel) first');
  var products = (msg.payload && msg.payload.products) || [];
  var known = {}, text = '';
  products.forEach(function (p) {
    text += '\n' + p.id + ' = ' + String(p.name || '').slice(0, 120) + '\n';
    var pf = p.profile || {};
    var facts = [];
    if (pf.category) facts.push('category: ' + String(pf.category).slice(0, 40));
    if (pf.price) facts.push('price: Rp ' + pf.price);
    if (pf.netto) facts.push('size: ' + String(pf.netto).slice(0, 20));
    if (pf.perUnit) facts.push('price per unit: Rp ' + pf.perUnit + ' per ' + String(pf.unit || 'ml/g').slice(0, 6));
    if (pf.texture) facts.push('texture: ' + String(pf.texture).slice(0, 80));
    if (pf.finish) facts.push('finish: ' + String(pf.finish).slice(0, 80));
    if (Array.isArray(pf.ingredients) && pf.ingredients.length) facts.push('key ingredients: ' + pf.ingredients.slice(0, 8).map(function (x) { return String(x).slice(0, 80); }).join('; '));
    if (pf.description) facts.push('product description: ' + String(pf.description).slice(0, 450));
    if (facts.length) text += '  PROFILE: ' + facts.join(' | ') + '\n';
    (p.lines || []).forEach(function (l) { known[l.id] = String(l.text || '').slice(0, 300); text += '  ' + l.id + ' [' + l.kind + ']: ' + known[l.id] + '\n'; });
  });
  if (!Object.keys(known).length) throw new Error('No claims to compare yet. Run the AI reading in the side panel first');
  var prompt =
    'You help a beauty brand researcher build a claim comparison matrix of competitor products. Below are the claims each product makes on its Shopee page (Indonesian and/or English). Every line has an ID.\n' +
    'Task: group the claims into standardized claim labels, and for each product give the short phrase that proves that claim.\n' +
    'RULES\n' +
    '1. Labels: crisp beauty-research labels of 1 to 3 words in English, for example Hydration, Long-lasting, Glossy finish, Matte finish, Plumping, Lightweight, Even stain, Non-sticky, Transfer-proof, Brightening, Even tone, Dark spots, Barrier care, Fast absorption, SPF. Reuse the same label for the same idea; invent a new label only when none of these fits.\n' +
    '2. Return the 12 to 15 claims made by the most products, most products first. Skip pure slogans that make no claim.\n' +
    '3. For every product that makes a claim, return the line ID and "phrase": ONLY the short clause of that line that proves this exact claim, copied exactly as written (same words, same language, same spelling). Never paste a whole multi-benefit sentence into several claims. Example: the line "Glossy, staining tahan lama dan merata pada bibir serta tidak membuat kering" gives Glossy finish -> "Glossy", Long-lasting -> "staining tahan lama", Even stain -> "merata pada bibir", Hydration -> "tidak membuat kering".\n' +
    '4. Give each statement to its primary claim only. Do not repeat the same phrase of a product under several labels. One phrase per product per claim.\n' +
    '5. Use only the IDs given. Never invent, translate or reword text.\n' +
    'PATTERN. Also write "pattern": exactly 3 short insights across ALL the products, each 1 to 2 sentences (maximum 50 words), in English, naming products by brand or product name. Use only the claims and PROFILE facts given below; never invent a number, never guess a missing price.\n' +
    '  tableStakes = Market table stakes vs white space: which claims almost every product makes (mandatory), and which claims only one or two products make (possible differentiators).\n' +
    '  communication = Communication and hook angle: the numbers (for example hours, percentages, SPF), sensory words and copywriting hooks that dominate the claims and descriptions.\n' +
    '  formulaPrice = Formula and price-to-benefit: common active ingredient and texture pairings, and how the price per unit relates to the claims each product offers (for example whether the pricier products claim more or different things). If prices are missing for most products, say that the price comparison is not possible.\n' +
    'Return JSON only: {"claims":[{"label":"Hydration","items":[{"ref":"P1.h0","phrase":"tidak membuat kering"}]}],"pattern":{"tableStakes":"...","communication":"...","formulaPrice":"..."}}\n' + text;
  var res = await fetch(endpointFor(AI_DEFAULT_MODEL), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', maxOutputTokens: 8192 } })
  });
  var js = await res.json().catch(function () { return {}; });
  if (!res.ok) throw new Error((js.error && js.error.message) || ('Gemini answered HTTP ' + res.status));
  if (js.promptFeedback && js.promptFeedback.blockReason) throw new Error('Gemini did not accept the request (' + js.promptFeedback.blockReason + ')');
  var cand = js.candidates && js.candidates[0];
  var out = cand && cand.content && cand.content.parts ? cand.content.parts.map(function (x) { return x.text || ''; }).join('') : '';
  if (!out) throw new Error('Gemini sent no text (' + ((cand && cand.finishReason) || 'no reason given') + ')');
  var data;
  try { data = JSON.parse(out); }
  catch (e) { throw new Error('Gemini answer was cut or not valid JSON (' + ((cand && cand.finishReason) || 'unknown') + ')'); }

  var merged = {}, order = [], usedPhrase = {};   // usedPhrase: a product's phrase is shown under one claim only
  (Array.isArray(data.claims) ? data.claims : []).forEach(function (c) {
    var label = String(c && c.label || '').replace(/\s+/g, ' ').trim().slice(0, 40);
    if (!label) return;
    var k = label.toLowerCase(), items = [];
    (Array.isArray(c.items) ? c.items : []).forEach(function (it) {
      var ref = String(it && it.ref || '');
      if (!known[ref]) return;
      var pid = ref.split('.')[0], phrase = String(it.phrase || '').replace(/\s+/g, ' ').trim();
      if (!phrase || normForMatch(known[ref]).indexOf(normForMatch(phrase)) < 0) phrase = known[ref];   // not found in the original: show the whole original line
      var pk = pid + '|' + normForMatch(phrase);
      if (usedPhrase[pk] && usedPhrase[pk] !== k) return;                                               // already used for another claim of this product
      if (items.some(function (x) { return x.ref.split('.')[0] === pid; }) || (merged[k] && merged[k].items.some(function (x) { return x.ref.split('.')[0] === pid; }))) return;
      usedPhrase[pk] = k; items.push({ ref: ref, phrase: phrase });
    });
    if (!items.length) return;
    if (!merged[k]) { merged[k] = { label: label, items: [] }; order.push(k); }
    merged[k].items = merged[k].items.concat(items);
  });
  if (!order.length) throw new Error('Gemini found no claims to group. Try again');
  var pt = data.pattern || {}, pattern = {
    tableStakes: String(pt.tableStakes || '').replace(/\s+/g, ' ').trim().slice(0, 500),
    communication: String(pt.communication || '').replace(/\s+/g, ' ').trim().slice(0, 500),
    formulaPrice: String(pt.formulaPrice || '').replace(/\s+/g, ' ').trim().slice(0, 500)
  };
  if (!pattern.tableStakes && !pattern.communication && !pattern.formulaPrice) pattern = null;   // the matrix still works without it
  return { ok: true, claims: order.map(function (k) { return merged[k]; }), pattern: pattern, model: AI_DEFAULT_MODEL, at: new Date().toISOString() };
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || !msg.type) return;
  var job = null;
  if (msg.type === 'PDP_SAVE') job = handleSave(msg);
  else if (msg.type === 'PDP_REDOWNLOAD') job = handleRedownload(msg);
  else if (msg.type === 'PDP_AI_ANALYZE') job = handleAiAnalyze(msg);
  else if (msg.type === 'PDP_CLAIM_MATRIX') job = handleClaimMatrix(msg);
  else if (msg.type === 'PDP_SLIDE_TYPES') job = handleSlideTypes(msg);
  else return;
  job.then(sendResponse, function (err) { sendResponse({ ok: false, error: String(err && err.message || err) }); });
  return true; // answer asynchronously
});
