/* Civil War side panel: scans the Shopee product page of the active tab, lets you fix every
 * field, then saves. It stays open and follows you when you change tab or product.
 * 0.5.2: the work on each product (scan, edits, removed pictures, AI reading) is kept as a draft in
 * chrome.storage.local, keyed by the clean product URL, and restored when you come back to that product. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var STATES = ['s-loading', 's-reload', 's-notproduct', 's-unreadable', 's-ready'];
  var FIELDS = ['f-name', 'f-brand', 'f-maincat', 'f-cat', 'f-netto', 'f-price', 'f-var', 'f-key', 'f-pdesc'];
  var AI_FIELDS = ['ai-claims', 'ai-rtb', 'ai-ing', 'ai-texture', 'ai-finish', 'ai-skin', 'ai-howto'];
  var AI_MODEL_DEFAULT = 'gemini-3.5-flash-lite';
  var AI_MODEL_CHOICES = ['gemini-3.5-flash-lite', 'gemini-3.6-flash'];
  var AI_MAX_PICTURES = 14;   // keep in step with AI_MAX_IMAGES in background.js
  var aiMeta = null;        // { model, analyzedAt, imagesSent, imagesSkipped } of the last AI reading of this product
  var aiSources = {};       // item text -> source ("Slide 2", "Desc 1", "Description text"); shown nowhere, saved with the data
  var aiAudit = null;       // banners-vs-description audit from the last AI reading (saved with the data, not shown)
  var aiBusy = false;
  var removed = {};         // product key -> { pictureId: true } for pictures taken out with the × button (or that would not load)
  var removedByUser = {};   // same, only the ones the user removed by hand
  var curKey = '';
  var descTried = {};       // product keys for which the description was already loaded by scrolling
  var persistTimer = null;  // pending save of the draft

  var forcedTab = new URLSearchParams(location.search).get('tab');   // used by the automated test only
  var tab = null;
  var current = null;       // { status, record } from the page
  var shownKey = null;      // which product the form is showing
  var dirty = {};           // fields the user has typed in (never overwritten by a re-scan)
  var pollTimer = null, schedTimer = null, runId = 0;

  function show(id) { STATES.forEach(function (s) { $(s).hidden = s !== id; }); $('foot').hidden = id !== 's-ready'; }
  function badge() { /* the status badge is gone from the header; the yellow notice in the form still says when details did not load */ }
  // opens the live website when the shared database is on, otherwise the same page inside the extension
  function openPage(page) {
    var c = window.CW_CONFIG || {}, online = c.useCloud && c.siteUrl;
    chrome.tabs.create({ url: online ? c.siteUrl.replace(/\/?$/, '/') + page : chrome.runtime.getURL('dashboard/' + page) });
  }

  async function findTab() {
    if (forcedTab) return chrome.tabs.get(parseInt(forcedTab, 10));
    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs[0] || null;
  }

  function ask(tabId, type, extra) {
    return new Promise(function (resolve) {
      try {
        chrome.tabs.sendMessage(tabId, Object.assign({ type: type || 'PDP_GET' }, extra || {}), function (res) {
          if (chrome.runtime.lastError || !res) resolve(null); else resolve(res);
        });
      } catch (e) { resolve(null); }
    });
  }

  // ---------- drafts: the work on one product, kept across tab switches ----------
  function cleanUrl(u) { return String(u || '').split('#')[0].split('?')[0]; }
  function draftKey(u) { return 'draftState_' + cleanUrl(u); }
  async function loadDraft(u) {
    var k = draftKey(u);
    var d = await chrome.storage.local.get(k);
    return d[k] || null;
  }
  function collectFields() {
    var f = {};
    FIELDS.concat(AI_FIELDS).forEach(function (id) { f[id] = $(id).value; });
    return f;
  }
  // builds the draft synchronously (so it always matches what the form shows), then stores it
  function persistNow() {
    persistTimer = null;
    if (!current || !curKey) return;
    var rec = current.record;
    var url = rec.url || (tab && tab.url) || '';
    var draft = {
      savedAt: new Date().toISOString(),
      url: cleanUrl(url),
      status: current.status,
      record: rec,
      fields: collectFields(),
      newLaunch: !!$('f-newlaunch').checked,
      dirty: dirty,
      aiMeta: aiMeta,
      aiSources: aiSources,
      aiAudit: aiAudit,
      removed: removed[curKey] || {},
      removedByUser: removedByUser[curKey] || {}
    };
    var o = {};
    o[draftKey(url)] = draft;
    chrome.storage.local.set(o).catch(function () { /* storage unavailable: the panel keeps working */ });
  }
  function schedulePersist() { clearTimeout(persistTimer); persistTimer = setTimeout(persistNow, 400); }
  function flushPersist() { if (persistTimer) { clearTimeout(persistTimer); persistNow(); } }
  function applyDraft(d, key) {
    Object.keys(d.fields || {}).forEach(function (id) { if ($(id)) $(id).value = d.fields[id]; });
    $('f-newlaunch').checked = !!d.newLaunch;
    dirty = Object.assign({}, d.dirty || {});
    aiMeta = d.aiMeta || null;
    aiSources = Object.assign({}, d.aiSources || {});
    // drafts saved by 0.5.2 kept the audit as text in "ai-audit": read it once, so nothing is lost
    aiAudit = d.aiAudit || (d.fields && d.fields['ai-audit'] ? parseAuditText(d.fields['ai-audit']) : null);
    removed[key] = Object.assign({}, d.removed || {});
    removedByUser[key] = Object.assign({}, d.removedByUser || {});
    descTried[key] = true;    // the description was loaded before: do not scroll the page again
  }
  function hasEdits() {
    return Object.keys(dirty).length > 0 || !!aiMeta ||
      AI_FIELDS.some(function (f) { return $(f).value.trim(); }) ||
      Object.keys(removedByUser[curKey] || {}).length > 0;
  }

  function schedule(delay) {
    clearTimeout(schedTimer);
    schedTimer = setTimeout(function () { scan(false); }, delay === undefined ? 350 : delay);
  }

  // ---------- scanning ----------
  async function scan(force) {
    flushPersist();           // save what the form shows before the panel moves to another tab or product
    var my = ++runId;
    clearTimeout(pollTimer);
    if (force || !current) { badge(null); if (!current || force) show('s-loading'); }
    tab = await findTab();
    if (my !== runId) return;
    if (!tab || !tab.url || !/^https:\/\/shopee\.co\.id\//.test(tab.url) || !PDP.parseProductUrl(tab.url)) {
      current = null; shownKey = null; dirty = {}; badge(null); show('s-notproduct'); return;
    }
    var tries = 0;
    (function poll() {
      ask(tab.id).then(function (res) {
        if (my !== runId) return;
        if (res === null) { current = null; badge(null); show('s-reload'); return; }
        if (res.status === 'not-product') { current = null; show('s-notproduct'); return; }
        if (res.status === 'complete' || res.status === 'partial') { current = res; render(force); return; }
        if (++tries < 14) { pollTimer = setTimeout(poll, 700); return; }
        current = null; badge(null); show('s-unreadable');
      });
    })();
  }

  // ---------- the form ----------
  function setField(id, value) {
    if (dirty[id]) return;                                   // the user already typed here: keep it
    $(id).value = (value === null || value === undefined) ? '' : value;
  }
  // text boxes grow with their content (the hidden ones are sized when they are shown)
  function fitOne(el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; }
  function fitAll() { document.querySelectorAll('textarea.auto').forEach(fitOne); }
  // The AI-filled fields stay hidden until there is something in them (an AI reading, or a product that already has AI data)
  var AI_BOXES = ['f-key', 'f-pdesc'].concat(AI_FIELDS);
  function syncAiFields() {
    var box = $('ai-fields'), has = !!aiMeta || AI_BOXES.some(function (id) { return $(id).value.trim(); });
    var wasHidden = box.hidden;
    box.hidden = !has;
    if (has && wasHidden) fitAll();                          // text boxes can only be sized once they are visible
  }

  async function render(force) {
    // a product the form is not showing yet (or a forced scan): bring back the saved work for it, if any
    var draft = null;
    var incoming = PDP.recordKey(current.record) + '|' + current.record.url;
    if (force || incoming !== shownKey) draft = await loadDraft(current.record.url || (tab && tab.url));
    if (draft) current = { status: draft.status, record: draft.record };

    var rec = current.record;
    var partial = current.status === 'partial';
    var key = PDP.recordKey(rec) + '|' + rec.url;
    if (force || key !== shownKey) {
      dirty = {}; shownKey = key; curKey = key;
      FIELDS.forEach(function (f) { $(f).value = ''; });
      AI_FIELDS.forEach(function (f) { $(f).value = ''; });
      aiMeta = null; aiSources = {}; aiAudit = null; setAiStatus('');
      $('f-newlaunch').checked = false;
      $('save-error').hidden = true; $('save-ok').hidden = true; $('save-note').hidden = true;
      if (draft) applyDraft(draft, key);
    }
    $('restore-note').hidden = !draft;

    // (header status badge removed)
    // the Reload button appears only when key details are missing (not on every page)
    var rr = current.record;
    var missing = !rr.title || !rr.price || !(rr.netto && rr.netto.text) || !(rr.images || []).length;
    $('reload-notice').hidden = !missing;

    curKey = key;
    redrawPics();

    var hint = await CWStore.hints(PDP.recordKey(rec));
    var inf = rec.inferred || {};

    setField('f-name', rec.title);
    setField('f-brand', rec.brand);
    setField('f-netto', rec.netto && rec.netto.text);
    setField('f-price', rec.price);
    setField('f-var', (rec.variants || []).join(', '));
    drawTags();
    var hn = $('h-name'); hn.hidden = !(rec.fullTitle && rec.fullTitle !== rec.title) || !!dirty['f-name'];
    $('f-name').title = rec.fullTitle ? 'Full Shopee title: ' + rec.fullTitle : '';
    var hv = $('h-var'), nd = rec.shadesFromDescription || 0;
    hv.hidden = !nd || !!dirty['f-var'];
    hv.textContent = nd + (nd === 1 ? ' shade' : ' shades') + ' added from the description text';
    setField('f-cat', rec.suggestedCategory || hint.settings.lastCategory || '');
    setField('f-maincat', rec.suggestedMainCategory || PDP.mainCategoryFor($('f-cat').value) || '');

    var d = (rec.description || '').replace(/\s+/g, ' ').trim();
    $('p-desc').textContent = d ? (d.length > 220 ? d.slice(0, 220) + '…' : d) : (loadingDesc ? 'Loading the description… the page scrolls down and back by itself.' : 'No description text found yet.');
    $('load-desc').hidden = !!d || loadingDesc;
    // the description is drawn by Shopee only when scrolled to: fetch it once per product, automatically
    if (!loadingDesc && !descTried[key]) { descTried[key] = true; loadDesc(!d, key); }

    var cats = {};
    hint.categories.forEach(function (c) { cats[c] = 1; });
    var dl = $('cats'); dl.textContent = '';
    Object.keys(cats).sort().forEach(function (c) { var o = document.createElement('option'); o.value = c; dl.appendChild(o); });

    var last = hint.lastCapturedAt ? { capturedAt: hint.lastCapturedAt } : null;
    var note = $('exists-note');
    if (last) { note.hidden = false; note.textContent = 'Already in your library (saved ' + PDP.fmtDate(last.capturedAt) + '). Saving again adds a new dated snapshot.'; }
    else note.hidden = true;

    $('save').disabled = false;
    show('s-ready');
    syncAiFields();
    fitAll();
    schedulePersist();        // the scraped data and the form are now saved as this product's draft
  }


  // ---------- picture grids: +N expands in place, click opens the lightbox ----------
  var LIMIT = 9;                 // thumbnails shown before the "+N" tile
  var expanded = { gallery: false, desc: false };
  function pics(list) {
    var gone = removed[curKey] || {};
    return (list || []).filter(function (u) { return !gone[PDP.imgKey(u)]; });
  }
  function removePic(u, byUser) {
    var k = PDP.imgKey(u);
    (removed[curKey] = removed[curKey] || {})[k] = true;
    if (byUser) (removedByUser[curKey] = removedByUser[curKey] || {})[k] = true;
    redrawPics();
    schedulePersist();
  }
  function redrawPics() {
    var rec = current && current.record;
    if (!rec) return;
    var imgs = pics(rec.images), di = pics(rec.descImages);
    $('banner-count').textContent = imgs.length + (imgs.length === 1 ? ' banner image found' : ' banner images found') + ' (main gallery)';
    drawThumbs($('thumbs'), imgs, 'gallery', 'Banner');
    $('desc-img-count').textContent = di.length ? di.length + (di.length === 1 ? ' image' : ' images') + ' from the description' : '';
    drawThumbs($('desc-thumbs'), di, 'desc', 'Description image');
    var nUser = Object.keys(removedByUser[curKey] || {}).length;
    var rb = $('restore-imgs');
    rb.hidden = !nUser;
    rb.textContent = nUser + (nUser === 1 ? ' picture' : ' pictures') + ' removed · Undo';
  }
  function drawThumbs(box, urls, group, label) {
    box.textContent = '';
    var shown = expanded[group] ? urls : urls.slice(0, LIMIT);
    shown.forEach(function (u, i) {
      var t = document.createElement('div');
      t.className = 'thumb';
      var img = document.createElement('img');
      img.alt = label + ' ' + (i + 1);
      img.title = label + ' ' + (i + 1) + ': click to enlarge';
      img.referrerPolicy = 'no-referrer';
      // a picture that cannot be loaded (or loads blank) is dropped, so there are no empty grey squares
      img.onerror = function () { removePic(u, false); };
      img.onload = function () { if (!img.naturalWidth) removePic(u, false); };
      img.src = u;
      img.onclick = function () { openLightbox(urls, i, label); };
      t.appendChild(img);
      var x = document.createElement('button');
      x.type = 'button'; x.className = 'x'; x.textContent = '×';
      x.title = 'Remove this picture'; x.setAttribute('aria-label', 'Remove ' + label + ' ' + (i + 1));
      x.onclick = function (e) { e.stopPropagation(); removePic(u, true); };
      t.appendChild(x);
      box.appendChild(t);
    });
    if (urls.length > LIMIT) {
      var m = document.createElement('button');
      m.type = 'button'; m.className = 'thumb more';
      m.setAttribute('aria-expanded', expanded[group] ? 'true' : 'false');
      m.textContent = expanded[group] ? 'Less' : '+' + (urls.length - LIMIT);
      m.title = expanded[group] ? 'Show fewer' : 'Show all ' + urls.length + ' images';
      m.onclick = function () { expanded[group] = !expanded[group]; drawThumbs(box, urls, group, label); };
      box.appendChild(m);
    }
  }
  $('restore-imgs').onclick = function () {
    var gone = removed[curKey] || {};
    Object.keys(removedByUser[curKey] || {}).forEach(function (k) { delete gone[k]; });
    removedByUser[curKey] = {};
    redrawPics();
    schedulePersist();
  };

  var lb = { urls: [], i: 0, label: '' };
  function lbShow() {
    var u = lb.urls[lb.i];
    var img = $('lb-img');
    img.classList.remove('zoomed');
    $('lb-body').scrollTo(0, 0);
    img.src = u;
    $('lb-count').textContent = lb.label + ' ' + (lb.i + 1) + ' of ' + lb.urls.length;
    $('lb-open').href = u;
    $('lb-prev').disabled = lb.i === 0;
    $('lb-next').disabled = lb.i === lb.urls.length - 1;
  }
  function openLightbox(urls, i, label) {
    lb = { urls: urls.slice(), i: i, label: label };
    $('lightbox').hidden = false;
    lbShow();
    $('lb-close').focus();
  }
  function closeLightbox() { $('lightbox').hidden = true; $('lb-img').removeAttribute('src'); }
  function lbMove(d) { var n = lb.i + d; if (n >= 0 && n < lb.urls.length) { lb.i = n; lbShow(); } }
  $('lb-close').onclick = closeLightbox;
  $('lb-prev').onclick = function () { lbMove(-1); };
  $('lb-next').onclick = function () { lbMove(1); };
  $('lb-img').onclick = function () { this.classList.toggle('zoomed'); };       // click the picture: actual size, scroll to read small text
  $('lightbox').addEventListener('click', function (e) { if (e.target === this || e.target === $('lb-body')) closeLightbox(); });
  document.addEventListener('keydown', function (e) {
    if ($('lightbox').hidden) return;
    if (e.key === 'Escape') closeLightbox();
    else if (e.key === 'ArrowLeft') lbMove(-1);
    else if (e.key === 'ArrowRight') lbMove(1);
  });

  var loadingDesc = false;
  var galRetried = {};
  async function loadDesc(needDesc, key) {
    if (!tab || loadingDesc) return;
    needDesc = needDesc !== false;      // (a click on the link passes an event: treat as true)
    loadingDesc = true;
    if (needDesc) { $('p-desc').textContent = 'Loading the description… the page scrolls down and back by itself.'; $('load-desc').hidden = true; }
    $('banner-count').textContent = 'Checking for more banners behind the > arrow…';
    var lr = await ask(tab.id, 'PDP_LOAD_DESC', { needDesc: needDesc });
    // a gallery that stops at 5 is suspicious (page may still have been drawing): look once more
    if (lr && lr.gallery && lr.gallery.total <= 5 && key && !galRetried[key]) {
      galRetried[key] = true;
      await new Promise(function (r) { setTimeout(r, 1500); });
      await ask(tab.id, 'PDP_LOAD_DESC', { needDesc: false });
    }
    loadingDesc = false;
    var res = await ask(tab.id);
    if (res && (res.status === 'complete' || res.status === 'partial')) { current = res; render(false); }
    else if (current) redrawPics();
  }

  function parseVariants(t) {
    var out = [];
    String(t || '').split(/[\n,]+/).forEach(function (x) { x = x.trim(); if (x && out.indexOf(x) < 0) out.push(x); });
    return out;
  }
  // the shades live in the hidden f-var box (comma list, saved as before); the pills only show them
  function setVariants(list) {
    $('f-var').value = list.join(', ');
    dirty['f-var'] = true;
    drawTags();
    $('save-ok').hidden = true;
    schedulePersist();
  }
  function drawTags() {
    var list = parseVariants($('f-var').value), box = $('var-tags');
    box.textContent = '';
    list.forEach(function (v, i) {
      var sp = document.createElement('span'); sp.className = 'tg';
      var label = document.createElement('span');
      label.className = 'tglabel'; label.textContent = v; label.title = 'Click to edit';
      label.onclick = function () { editShade(sp, list, i); };
      sp.appendChild(label);
      var x = document.createElement('button');
      x.type = 'button'; x.className = 'tgx'; x.textContent = '×';
      x.title = 'Remove ' + v; x.setAttribute('aria-label', 'Remove shade ' + v);
      x.onclick = function () { setVariants(list.filter(function (_, j) { return j !== i; })); };
      sp.appendChild(x);
      box.appendChild(sp);
    });
  }
  // click a shade to edit its text (for example to remove a "[PROMO]" tag). Enter or leaving the box saves;
  // Esc cancels; an empty name removes the shade.
  function editShade(sp, list, i) {
    if (sp.classList.contains('edit')) return;
    sp.classList.add('edit');
    sp.textContent = '';
    var inp = document.createElement('input');
    inp.type = 'text'; inp.value = list[i]; inp.maxLength = 80; inp.setAttribute('aria-label', 'Edit shade');
    sp.appendChild(inp);
    inp.focus(); inp.select();
    var done = false;
    function finish(save) {
      if (done) return; done = true;
      var v = inp.value.replace(/,/g, ' ').replace(/\s+/g, ' ').trim();
      var next = list.slice();
      if (save) { if (v) next[i] = v; else next.splice(i, 1); }
      var uniq = [];
      next.forEach(function (x) { if (uniq.indexOf(x) < 0) uniq.push(x); });
      if (save && uniq.join('|') !== list.join('|')) setVariants(uniq); else drawTags();
    }
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      else if (e.key === 'Escape') { e.preventDefault(); finish(false); }
    });
    inp.addEventListener('blur', function () { finish(true); });
  }

  function numFromText(t) {
    var d = String(t || '').replace(/[^\d]/g, '');
    return d ? parseInt(d, 10) : null;
  }
  function nettoFromText(t) {
    t = String(t || '').trim();
    if (!t) return null;
    return PDP.guessNetto([t]) || { value: null, unit: '', text: t };   // keep what was typed even if it has no number + unit
  }

  // Save keeps the form on screen: only a green banner near the button confirms it.
  async function save() {
    var btn = $('save');
    var title = $('f-name').value.trim();
    var err = $('save-error');
    if (!title) { err.hidden = false; err.textContent = 'Please type a product name first.'; $('f-name').focus(); return; }
    btn.disabled = true; btn.textContent = 'Saving…'; err.hidden = true; $('save-ok').hidden = true; $('save-note').hidden = true;

    // take the freshest picture lists from the page (more may have been found since the panel drew them)
    try {
      var fresh = await ask(tab.id);
      if (fresh && fresh.record) {
        if ((fresh.record.images || []).length > current.record.images.length) current.record.images = fresh.record.images;
        if ((fresh.record.descImages || []).length > (current.record.descImages || []).length) current.record.descImages = fresh.record.descImages;
      }
    } catch (e) { /* keep what the panel has */ }
    var rec = Object.assign({}, current.record, {
      title: title,
      brand: $('f-brand').value.trim(),
      category: $('f-cat').value.trim(),
      mainCategory: PDP.cleanMainCategory($('f-maincat').value),
      netto: nettoFromText($('f-netto').value),
      price: numFromText($('f-price').value),
      priceBefore: null,
      variants: parseVariants($('f-var').value),
      images: pics(current.record.images),
      descImages: pics(current.record.descImages),
      keyMessage: $('f-key').value.trim(),
      productDescription: $('f-pdesc').value.trim(),
      ai: readAiForm()
    });
    rec.isOfficial = /official/i.test(rec.shopName) || !!current.record.isOfficial;
    // "New Product Launch": the dashboard shows a NEW LAUNCH badge for 28 days after this date
    if ($('f-newlaunch').checked) { rec.isNewLaunch = true; rec.newLaunchMarkedAt = new Date().toISOString(); }
    else { delete rec.isNewLaunch; delete rec.newLaunchMarkedAt; }
    var res, startedAt = new Date().toISOString();
    try { res = await chrome.runtime.sendMessage({ type: 'PDP_SAVE', record: rec, download: false }); }
    catch (e) { res = { ok: false, error: String(e) }; }
    if (!res || !res.ok) {
      // Chrome sometimes closes the channel while the background worker restarts: check whether the save did go through
      try {
        await new Promise(function (r) { setTimeout(r, 700); });
        var h2 = await CWStore.hints(PDP.recordKey(rec));
        var hit = !!h2.lastCapturedAt && h2.lastCapturedAt >= startedAt;
        if (hit) res = { ok: true, download: null };
      } catch (e2) { /* keep the error */ }
    }
    btn.textContent = 'Save to Library';
    btn.disabled = false;
    if (!res || !res.ok) {
      err.hidden = false;
      err.textContent = 'Could not save: ' + ((res && res.error) || 'no answer from the extension') + '. Try again.';
      return;
    }
    showSaved();
    schedulePersist();
    // shared database only: copy this product's banner pictures into the shared storage in the background (silent; Library tools can finish it later)
    if (window.CWImages && CWStore.name === 'cloud') CWImages.copyProduct(res.key || PDP.recordKey(rec)).catch(function () { /* the catch-up button handles it */ });
  }


  // stay on the form: green banner (saving goes straight to the library; nothing is downloaded to the computer)
  function showSaved() {
    $('save-ok').hidden = false;
    var note = $('save-note');
    note.hidden = true; note.className = 'note';
    var ex = $('exists-note');
    ex.hidden = false;
    ex.textContent = 'Saved just now. Saving again adds a new dated snapshot.';
  }

  // ---------- Phase 2: AI settings (key and options stay in this browser only) ----------
  function setAiKeyNote(t) { $('ai-key-note').textContent = t; }
  // The settings panel is shown by itself only while there is no key. Once a key is saved it hides, and the small gear in the header opens it again.
  var hasAiKey = false;
  function setAiPanel(open) {
    $('ai-settings').hidden = !open;
    $('ai-gear').setAttribute('aria-expanded', String(!!open));
    $('ai-set-h').textContent = hasAiKey ? 'AI Settings' : 'Add your Gemini API key to use the AI reading';
  }
  function setAiKeyState(has, open) {
    hasAiKey = !!has;
    $('ai-gear').hidden = !hasAiKey;
    setAiPanel(hasAiKey ? !!open : true);
  }
  function setAiStatus(t, kind) {
    var b = $('ai-status');
    b.hidden = !t;
    b.className = kind === 'err' ? 'error' : (kind === 'ok' ? 'note info' : 'note');
    b.textContent = t || '';
  }
  function modelOrDefault(m) { return AI_MODEL_CHOICES.indexOf(m) >= 0 ? m : AI_MODEL_DEFAULT; }
  async function loadAiSettings() {
    var d = await chrome.storage.local.get({ aiSettings: {} });
    var s = d.aiSettings || {};
    $('ai-key').value = s.apiKey || '';
    $('ai-images').checked = s.includeImages !== false;
    $('ai-model').value = modelOrDefault(s.model);
    setAiKeyState(!!s.apiKey, false);           // no key yet: the panel shows by itself; key saved: only the gear is left
    setAiKeyNote(s.apiKey ? 'Key saved on this computer.' : 'No key saved yet.');
  }
  async function saveAiKey() {
    var key = $('ai-key').value.trim();
    var d = await chrome.storage.local.get({ aiSettings: {} });
    await chrome.storage.local.set({ aiSettings: Object.assign({}, d.aiSettings || {}, { apiKey: key }) });
    setAiKeyNote(key ? 'Key saved on this computer only.' : 'Key removed.');
    setAiKeyState(!!key, false);                // a saved key tucks the panel away; removing it brings the panel back
    if (key) setAiStatus('Key saved on this computer. Press Analyze when you are ready.', 'ok');
  }
  async function saveAiModel() {
    var d = await chrome.storage.local.get({ aiSettings: {} });
    await chrome.storage.local.set({ aiSettings: Object.assign({}, d.aiSettings || {}, { model: modelOrDefault($('ai-model').value) }) });
  }
  async function saveAiImagesOption() {
    var d = await chrome.storage.local.get({ aiSettings: {} });
    await chrome.storage.local.set({ aiSettings: Object.assign({}, d.aiSettings || {}, { includeImages: $('ai-images').checked }) });
  }

  // ---------- Phase 2: the AI reading ----------
  // The text boxes show plain lines. The source of each line ("Slide 2", "Desc 1", ...) is kept in aiSources,
  // so it is saved with the record and shown on the dashboard, but never typed into the text.
  function listText(items) {
    return (items || []).map(function (x) { return x.text; }).join('\n');
  }
  function parseAuditText(t) {
    return String(t || '').split('\n').map(function (line) {
      var p = line.split('|').map(function (x) { return x.trim(); });
      return p[0] ? { claim: p[0], banners: p[1] || 'Not mentioned', description: p[2] || 'Not mentioned' } : null;
    }).filter(Boolean);
  }
  function rememberSources(lists) {
    aiSources = {};
    lists.forEach(function (items) {
      (items || []).forEach(function (x) { if (x && x.text && x.source) aiSources[x.text] = x.source; });
    });
  }
  function parseList(t) {
    return String(t || '').split('\n').map(function (line) {
      line = line.trim();
      return line ? { text: line, source: aiSources[line] || '' } : null;
    }).filter(Boolean);
  }
  // what the AI section holds right now (includes the user's edits); null when nothing was read or typed
  function readAiForm() {
    var any = !!aiMeta || AI_FIELDS.some(function (f) { return $(f).value.trim(); });
    if (!any) return null;
    return Object.assign({}, aiMeta || {}, {
      heroClaims: parseList($('ai-claims').value),
      rtb: parseList($('ai-rtb').value),
      keyIngredients: parseList($('ai-ing').value),
      texture: $('ai-texture').value.trim(),
      finish: $('ai-finish').value.trim(),
      targetSkin: $('ai-skin').value.trim(),
      howToUse: parseList($('ai-howto').value),
      audit: aiAudit || []
    });
  }

  async function analyzeAi() {
    if (aiBusy || !current) return;
    var st = await chrome.storage.local.get({ aiSettings: {} });
    var s = st.aiSettings || {};
    if (!s.apiKey) {
      setAiKeyState(false, true); $('ai-settings').scrollIntoView({ block: 'nearest' });
      setAiStatus('Paste your Gemini API key in ⚙️ AI Settings first, then press Analyze again.', 'err');
      return;
    }
    var rec = current.record;
    var useImgs = $('ai-images').checked;
    var nImg = pics(rec.images).length + pics(rec.descImages).length;
    aiBusy = true; $('analyze').disabled = true;
    var model = modelOrDefault($('ai-model').value);
    setAiStatus(useImgs
      ? 'Reading the description and up to ' + AI_MAX_PICTURES + ' of ' + nImg + ' pictures with ' + model + '… this can take 20 to 60 seconds.'
      : 'Reading the description text with ' + model + '…', 'info');

    var res;
    try {
      res = await chrome.runtime.sendMessage({
        type: 'PDP_AI_ANALYZE',
        payload: {
          title: $('f-name').value.trim() || rec.title,
          pageTitle: rec.pageTitle || rec.fullTitle || rec.title || '',
          shopName: rec.shopName || '',
          isOfficial: !!rec.isOfficial,
          priceText: numFromText($('f-price').value) ? 'Rp' + Math.round(numFromText($('f-price').value)).toLocaleString('id-ID') : '',
          shadeCandidates: dirty['f-var'] ? parseVariants($('f-var').value) : (rec.variantsRaw || rec.variants || []),
          brand: $('f-brand').value.trim() || rec.brand || '',
          category: $('f-cat').value.trim() || rec.category || '',
          mainCategory: PDP.cleanMainCategory($('f-maincat').value),
          description: rec.description || '',
          images: useImgs ? pics(rec.images) : [],
          descImages: useImgs ? pics(rec.descImages) : [],
          includeImages: useImgs,
          model: model
        }
      });
    } catch (e) { res = { ok: false, error: String(e) }; }
    aiBusy = false; $('analyze').disabled = false;

    if (!res || !res.ok) {
      setAiStatus('AI reading failed: ' + ((res && res.error) || 'no answer from the extension') + '. Your fields were not changed.', 'err');
      return;
    }
    // fill the fields, but never overwrite anything the user typed or changed
    var r = res.result, kept = [];
    var put = function (id, val) { if (dirty[id]) kept.push(id); else $(id).value = val || ''; };
    // the cleaned basics from the AI replace the scraped guesses, but never something you typed
    if (r.brand) put('f-brand', r.brand);
    if (r.productName) put('f-name', r.productName);
    if (r.shades && r.shades.length) { put('f-var', r.shades.join(', ')); if (!dirty['f-var']) drawTags(); }
    if (r.price && !numFromText($('f-price').value)) put('f-price', r.price);    // a price is only taken from the AI when the page scan found none
    put('f-key', r.singleKeyMessage);
    put('f-pdesc', r.productDescription);
    if (r.mainCategory) put('f-maincat', r.mainCategory);                       // the AI's classification, unless you already chose one
    if (r.category && !$('f-cat').value.trim()) put('f-cat', r.category);        // the specific type only when the field is empty
    put('ai-claims', listText(r.heroClaims));
    put('ai-rtb', listText(r.rtb));
    put('ai-ing', listText(r.keyIngredients));
    put('ai-texture', r.texture);
    put('ai-finish', r.finish);
    put('ai-skin', r.targetSkin);
    put('ai-howto', listText(r.howToUse));
    rememberSources([r.heroClaims, r.rtb, r.keyIngredients, r.howToUse]);
    aiAudit = r.audit || [];
    aiMeta = { model: res.meta.model, analyzedAt: res.meta.analyzedAt, imagesSent: res.meta.imagesSent, imagesSkipped: res.meta.imagesSkipped };
    syncAiFields();                              // reveal the AI fields right under the button
    schedulePersist();
    fitAll();

    var msgText = 'Reading done: ' + res.meta.imagesSent + ' pictures and the description were read.';
    if (res.meta.imagesSkipped && res.meta.imagesSkipped.length) msgText += ' Not read: ' + res.meta.imagesSkipped.join(', ') + '.';
    if (kept.length) msgText += ' Kept your own edits in ' + kept.length + ' field' + (kept.length === 1 ? '' : 's') + '.';
    setAiStatus(msgText + ' Check every field before you save.', 'ok');
  }

  // ---------- debug info (for when something is read wrongly) ----------
  async function copyDebug() {
    tab = await findTab();
    var info = { extension: chrome.runtime.getManifest().version, url: tab && tab.url ? tab.url.split('?')[0] : null, scan: current ? { status: current.status, images: current.record.images.length, titleRead: current.record.title } : null };
    var page = tab ? await ask(tab.id, 'PDP_DEBUG') : null;
    info.page = page || 'no answer from the page (reload it once)';
    var text = JSON.stringify(info, null, 2);
    $('debug-out').hidden = false;
    $('debug-text').value = text;
    var ok = false;
    try { await navigator.clipboard.writeText(text); ok = true; } catch (e) { /* fall back to the box */ }
    $('debug-msg').textContent = ok ? 'Copied. Paste it into the chat with Claude.' : 'Select the text below, copy it, and paste it into the chat with Claude.';
  }

  // Re-scan: a fresh start from the page for this product. Clears the saved draft, edits and AI reading.
  async function rescanNow() {
    if (aiBusy) return;
    if (hasEdits() && !confirm('Re-scan reads the page fresh. Your edits, removed pictures and AI reading for this product will be cleared. Continue?')) return;
    clearTimeout(persistTimer); persistTimer = null;
    var url = (current && current.record && current.record.url) || (tab && tab.url) || '';
    if (url && PDP.parseProductUrl(url)) await chrome.storage.local.remove(draftKey(url));
    descTried = {};
    if (curKey) { removed[curKey] = {}; removedByUser[curKey] = {}; }
    shownKey = null;
    scan(true);
  }

  // ---------- wiring ----------
  FIELDS.forEach(function (f) {
    $(f).addEventListener('input', function () {
      dirty[f] = true;
      if (f === 'f-var') drawTags();
      $('save-ok').hidden = true;
      schedulePersist();
    });
  });
  $('f-cat').addEventListener('input', function () {
    if (dirty['f-maincat']) return;
    var m = PDP.mainCategoryFor($('f-cat').value);
    if (m) $('f-maincat').value = m;
  });
  $('f-newlaunch').addEventListener('change', function () { $('save-ok').hidden = true; schedulePersist(); });
  AI_FIELDS.forEach(function (f) { $(f).addEventListener('input', function () { dirty[f] = true; schedulePersist(); }); });
  $('var-add').addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ',') return;
    e.preventDefault();
    var v = this.value.replace(/,/g, '').trim();
    this.value = '';
    if (!v) return;
    var list = parseVariants($('f-var').value);
    if (list.indexOf(v) < 0) list.push(v);
    setVariants(list);
  });
  document.addEventListener('input', function (e) { if (e.target.classList && e.target.classList.contains('auto')) fitOne(e.target); });
  $('toggle-raw').onclick = function () {
    var open = $('raw-box').hidden;
    $('raw-box').hidden = !open;
    this.textContent = open ? '▾ Hide raw description' : '▸ View raw description';
    this.setAttribute('aria-expanded', open ? 'true' : 'false');
  };
  $('analyze').onclick = analyzeAi;
  $('ai-save-key').onclick = saveAiKey;
  $('ai-images').addEventListener('change', saveAiImagesOption);
  $('ai-model').addEventListener('change', saveAiModel);

  $('reload-1').onclick = $('reload-2').onclick = $('reload-shop').onclick = function () {
    if (tab) chrome.tabs.reload(tab.id);
    show('s-loading'); schedule(1800);
  };
  $('load-desc').onclick = function () { loadDesc(true, null); };
  $('retry').onclick = function () { scan(true); };
  $('rescan-top').onclick = rescanNow;
  $('lib-top').onclick = function () { openPage('library.html'); };
  $('ai-gear').onclick = function () { setAiPanel($('ai-settings').hidden); if (!$('ai-settings').hidden) $('ai-settings').scrollIntoView({ block: 'nearest' }); };
  $('lib-1').onclick = function () { openPage('home.html'); };
  $('save').onclick = save;
  $('debug-1').onclick = copyDebug;
  $('debug-2').onclick = copyDebug;

  // follow the browser: other tab, new address, or new data arriving from the page
  if (!forcedTab) {
    chrome.tabs.onActivated.addListener(function () { schedule(); });
    chrome.tabs.onUpdated.addListener(function (id, change, t) {
      if (t.active && (change.url || change.status === 'complete')) schedule(450);
    });
    chrome.windows.onFocusChanged.addListener(function () { schedule(); });
  } else {
    chrome.tabs.onUpdated.addListener(function (id, change) { if (id === parseInt(forcedTab, 10) && (change.url || change.status === 'complete')) schedule(450); });
  }
  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === 'PDP_UPDATED') schedule(300);
  });

  loadAiSettings();
  scan(true);
})();
