/* Civil War - Shared database tools (one-time upload of this Chrome's library, and backups).
 * Works only inside the extension, because only the extension can read the library kept in this Chrome.
 * Nothing here deletes anything: not in Chrome, not in the shared database. */
(function () {
  'use strict';
  var h = Dash.h, app = document.getElementById('app');
  var L = window.CWStoreLocal, C = window.CWStoreCloud;
  var BATCH = 20;

  function todayStr() { return new Date().toISOString().slice(0, 10); }
  function download(name, obj) { Dash.saveBlob(name, new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' })); }
  function iso(x) { var d = new Date(x); return isNaN(d.getTime()) ? String(x) : d.toISOString(); }
  function productCount(snaps) { var k = {}; snaps.forEach(function (s) { k[PDP.recordKey(s)] = 1; }); return Object.keys(k).length; }
  function line(text, cls) { return h('div', { class: cls || 'small', style: 'margin:4px 0' }, text); }

  var status = h('div', { class: 'small' }, 'Checking…');
  var log = h('div', { role: 'status', style: 'margin-top:10px;font-size:13px;line-height:1.5' });
  var uploadBox = h('div');

  async function localData() {
    var d = await L.load(); d.sets = await L.getSets(); return d;
  }

  async function showStatus() {
    status.textContent = 'Checking…';
    try {
      var l = await localData(), c = await C.load(), cs = await C.getSets();
      status.textContent = '';
      status.appendChild(line('In this Chrome: ' + productCount(l.snapshots) + ' products (' + l.snapshots.length + ' saved versions), ' + Object.keys(l.notes).length + ' notes, ' + l.sets.length + ' saved sets.', 'small'));
      status.appendChild(line('In the shared database: ' + productCount(c.snapshots) + ' products (' + c.snapshots.length + ' saved versions), ' + Object.keys(c.notes).length + ' notes, ' + cs.length + ' saved sets.', 'small'));
    } catch (e) { status.textContent = 'Could not read the numbers: ' + (e.message || e); }
  }

  async function upload() {
    uploadBox.textContent = '';
    log.textContent = 'Reading your Chrome library…';
    try {
      var l = await localData();
      var have = {};
      (await C.raw.fetchAll('snapshots', 'product_key,captured_at', '')).forEach(function (r) { have[r.product_key + '|' + iso(r.captured_at)] = 1; });
      var todo = l.snapshots.filter(function (s) { return !have[PDP.recordKey(s) + '|' + iso(s.capturedAt || new Date(0).toISOString())]; });
      var skipped = l.snapshots.length - todo.length, done = 0;
      for (var i = 0; i < todo.length; i += BATCH) {
        var rows = todo.slice(i, i + BATCH).map(function (s) { return { product_key: PDP.recordKey(s), captured_at: s.capturedAt || new Date(0).toISOString(), data: s }; });
        await C.raw.sb('POST', 'snapshots', { body: rows, prefer: 'return=minimal' });
        done += rows.length; log.textContent = 'Uploading… ' + done + ' of ' + todo.length + ' saved versions';
      }
      var nk = Object.keys(l.notes), notesSent = 0;
      if (nk.length) {
        await C.raw.sb('POST', 'notes?on_conflict=product_key', { body: nk.map(function (k) { return { product_key: k, text: l.notes[k], updated_at: new Date().toISOString() }; }), prefer: 'resolution=ignore-duplicates,return=minimal' });
        notesSent = nk.length;
      }
      if (l.sets.length) {
        await C.raw.sb('POST', 'compare_sets?on_conflict=name', { body: l.sets.map(function (x) { return { name: x.name, keys: x.keys, saved_at: x.savedAt || new Date().toISOString() }; }), prefer: 'resolution=ignore-duplicates,return=minimal' });
      }
      log.textContent = 'Done. Uploaded ' + done + ' new saved versions' + (skipped ? ' (' + skipped + ' were already there and skipped)' : '') + ', checked ' + notesSent + ' notes and ' + l.sets.length + ' saved sets (existing ones are kept as they are). Nothing was deleted from your Chrome or from the shared database.';
      await showStatus();
    } catch (e) { log.textContent = 'Stopped: ' + (e.message || e) + '. Nothing was deleted. You can press the button again; versions already uploaded are skipped.'; }
  }

  // ---- banner pictures: copy from Shopee into the shared storage (products that are not done yet) ----
  var picStatus = h('div', { class: 'small', style: 'margin:4px 0' });
  var picLog = h('div', { role: 'status', class: 'small', style: 'margin-top:8px;line-height:1.5' });
  var picBtn;
  async function showPictures() {
    try {
      var c = await C.load(), keys = CWImages.pending(c.snapshots);
      picStatus.textContent = keys.length ? keys.length + ' product(s) still have banner pictures that are not copied yet.' : 'All banner pictures are copied to the shared storage.';
      if (picBtn) picBtn.disabled = !keys.length;
    } catch (e) { picStatus.textContent = 'Could not check the pictures: ' + (e.message || e); }
  }
  async function copyPictures() {
    picBtn.disabled = true;
    try {
      var c = await C.load(), keys = CWImages.pending(c.snapshots), copied = 0, failed = 0, bad = 0;
      for (var i = 0; i < keys.length; i++) {
        try {
          var r = await CWImages.copyProduct(keys[i], function (d, t) { picLog.textContent = 'Product ' + (i + 1) + ' of ' + keys.length + ' · picture ' + d + ' of ' + t + '. You can leave this page open and wait.'; });
          copied += r.copied; failed += r.failed;
        } catch (e) { bad++; picLog.textContent = 'Product ' + (i + 1) + ' skipped: ' + (e.message || e); }
      }
      picLog.textContent = 'Finished. Copied ' + copied + ' pictures' + (failed ? '; ' + failed + ' could not be copied (Shopee may have removed them or blocked them)' : '') + (bad ? '; ' + bad + ' product(s) skipped because of an error' : '') + '. Press the button again to retry the ones that failed.';
    } catch (e) { picLog.textContent = 'Stopped: ' + (e.message || e) + '. Nothing was deleted. You can press the button again.'; }
    await showPictures();
  }

  function askUpload() {
    uploadBox.textContent = '';
    uploadBox.appendChild(h('div', { class: 'small', style: 'margin:8px 0' }, 'This copies your Chrome library to the shared database. It never deletes anything, and running it twice does not create duplicates. Have you downloaded the backup above?'));
    uploadBox.appendChild(h('button', { type: 'button', class: 'btn primary', onclick: upload }, 'Yes, upload now'));
    uploadBox.appendChild(h('button', { type: 'button', class: 'btn', style: 'margin-left:8px', onclick: function () { uploadBox.textContent = ''; } }, 'Cancel'));
  }

  function card(title, children) { return h('section', { class: 'card', style: 'margin-bottom:14px;padding:16px' }, [h('h2', { style: 'margin:0 0 8px;font-size:15px' }, title)].concat(children)); }

  async function init() {
    app.appendChild(h('h1', { style: 'margin:0 0 4px' }, 'Shared database tools'));
    app.appendChild(h('div', { class: 'small', style: 'margin-bottom:14px' }, h('a', { href: 'home.html' }, '← Back to the Main page')));
    if (!L || !C) {
      app.appendChild(card('Not available here', [line('Open this page from the Civil War extension (Main page → "Shared database tools"). Only the extension can read the library saved in your Chrome.')]));
      return;
    }
    app.appendChild(card('What is where', [status, h('button', { type: 'button', class: 'btn', style: 'margin-top:8px', onclick: showStatus }, 'Check again')]));
    app.appendChild(card('1. Backup of this Chrome library (recommended first)', [
      line('Saves one file with all your products, notes and saved sets to your Downloads folder. Your Gemini key is not included.'),
      h('button', { type: 'button', class: 'btn', onclick: async function () { var l = await localData(); download('civil-war-chrome-backup-' + todayStr() + '.json', { snapshots: l.snapshots, notes: l.notes, settings: l.settings, compareSets: l.sets }); log.textContent = 'Backup file saved to your Downloads folder.'; } }, 'Download backup of my Chrome library')]));
    app.appendChild(card('2. Upload my Chrome library to the shared database', [
      line('Do this once. After it, your teammates can see your products on the website.'),
      h('button', { type: 'button', class: 'btn primary', onclick: askUpload }, 'Upload my Chrome library'), uploadBox]));
    if (window.CWImages) {
      picBtn = h('button', { type: 'button', class: 'btn primary', onclick: copyPictures }, 'Copy banner pictures now');
      app.appendChild(card('3. Copy banner pictures to the shared storage', [
        line('Shopee picture links can stop working, and the website needs its own copies to show and export them. Copies are saved once per picture. It can take several minutes for many products, and it is safe to repeat.'),
        picStatus, picBtn, picLog]));
      showPictures();
    }
    app.appendChild(card('Backup of the shared database', [
      line('Saves everything that is in the shared database as one file.'),
      h('button', { type: 'button', class: 'btn', onclick: async function () { try { var c = await C.load(), s = await C.getSets(); download('civil-war-shared-backup-' + todayStr() + '.json', { snapshots: c.snapshots, notes: c.notes, compareSets: s }); log.textContent = 'Backup file saved to your Downloads folder.'; } catch (e) { log.textContent = 'Could not make the backup: ' + (e.message || e); } } }, 'Download backup of the shared database')]));
    app.appendChild(log);
    showStatus();
  }
  init();
})();
