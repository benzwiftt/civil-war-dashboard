# Civil War – version 1.0.0

**1.0.0** – First full release (same features as 0.17.1). The download is now named `civil-war-extension-v1.0.0.zip` and unzips to a folder with the same name, so the version is always visible. When updating later, copy the new files into the folder you installed from the first time (its name keeps the old version number; that is fine). The website menu item "Settings" is now called "Guide". The menu stays at the top of the screen while you scroll.

**0.17.1** – New Civil War bag logo (extension icons, website tab icon, top-left of the menu; the name is never cut off). Pages now use the full window width at any zoom. New **Text: Compact | Normal** switch in the menu (Compact is the default and fits more on one screen; the choice is kept in this browser). Product detail: bigger brand name, Main category › Sub-category right under the product name, Shop shows the shop name as a link to the shop on Shopee, a thin line under the Product description title. Product library: the sub-category pill row is gone; New Launch is now a tab next to All / Skincare / Decorative / Personal Care (a sub-category picked from the Main page shows as a removable chip). Compare product: Clear all button; clearer lines in the Compare Description table; Save set / Saved sets pop-ups open under their own button.

**0.17.0** – New look for the website and the dashboard pages (approved design preview): plum header band with the menu as white pills, lavender page background, rounder cards, numbered sections, muted pastel category cards. Product library: search, Sort (now also Product name A–Z and Brand A–Z) and new **Group by** (Brand, Sub-category, Price range) inside one card, thin lines between products, "Compare selected" button at the top. Product detail: facts shown as cards under the header; raw description stays collapsed. Compare product: + Add product, Save set and Saved sets moved to the top; products appear as soon as you tick them; tabs renamed Compare Description and Claim Matrix; Claim Matrix shows the chosen products in their own card, and the Claims / Ingredients & Formula switch appears only after Analyze. Settings: extension status sits next to the title. No change to saving, AI or your library; the side panel is unchanged.

**0.16.1** – Added the Settings page (dashboard/extension.html) to the dashboard menu: download/install/update steps and Gemini key steps, with an "Extension detected" badge on the website.

**0.16.0** – (1) The zip now unpacks to a folder named `civil-war-extension`, the same as the zip name. (2) The website bridge now also tells the website which extension version is installed, so the website can show "Extension detected". No change to saving, AI, or your library.

Collects a competitor's Shopee product page into a library on your own computer:
name, brand, category, netto, price, variants/shades, description, key message, the banners of the MAIN gallery and the images inside the description, all at full size.
The side panel can also read the banners and description with Google Gemini (your own key, optional); only public banners and description text are sent, never your notes.

## First install

1. Unzip to a place that will not move, for example `Documents\Civil War\civil-war-extension`.
2. Chrome → `chrome://extensions` → turn on **Developer mode** (top right).
3. **Load unpacked** → choose the folder that contains `manifest.json`.
4. Click the puzzle-piece icon → **pin** Civil War.

## UPDATING from an earlier version (any earlier version → 0.8.3)

1. Close nothing. Copy the new files INTO THE SAME FOLDER, replacing the old ones.
   (The old `popup` folder is no longer used; it is fine to delete it.)
2. Go to `chrome://extensions`, find **Civil War**, click the circular **refresh** arrow on its card.
3. Reload any open Shopee tab once (F5).
Do NOT remove the extension and do NOT load it from a different folder: your saved library would be lost.
Chrome 114 or newer is needed for the side panel (check at `chrome://settings/help`).

## Use

1. Open a competitor product on shopee.co.id and click the Civil War icon: the **side panel** opens on the right and stays open while you browse. It follows you when you open another product or tab.
2. Check the badge: green **Complete data found**, or yellow **Some details missing** (read from the visible page).
3. Every field is a normal text box: **Product name, Brand, Category, Netto, Price, Variants / Shades, Key message**.
   Fix anything wrong. Brand, Category and Netto are guessed from the title ("Guessed from the title").
   What you typed is never overwritten when the panel re-scans.
   To collect ALL banners, the panel (once per product) briefly opens Shopee's full-screen gallery by clicking the big picture, reads every thumbnail, and closes it again. If that does not open, it clicks the > arrow of the thumbnail strip instead.
   In the panel, click the **+N** tile to show all pictures (**Less** collapses them) and click any picture to open the large preview: ‹ › or the arrow keys flip, click the picture for actual size, X or Esc closes.
   Every picture has a small **×** at its top-right corner: click it to drop a wrong picture (a link "N pictures removed · Undo" appears). Pictures that fail to load are removed automatically, and the pictures you removed are not saved.
   **Shades / Variants** holds real shades only: promo tags like [TOP1] are cleaned, shade lines in the description such as "03 Mocha" are added, and multi-piece or promo options (2 Pcs, + Tissue, BUY 1 GET 1, FS) are left out.
   **Product name** is cleaned automatically to the core name: promo tags, the brand (it has its own field), the size and SEO taglines after | or - are removed. The full Shopee title is kept in the saved data (hover over the name box to see it); you can always retype the name.
   The description is drawn by Shopee only when you scroll to it, so the panel scrolls the page down by itself once (then back up) to read it and its images. Don't scroll during those few seconds.
4. Press **Save to Library**. With the tick-box on, files go to
   `Downloads › PDP Library › <category> › <Brand – product name (date)>`: 01.jpg, 02.jpg … (gallery), desc-01.jpg … (description images), info.txt, data.json.
5. Tick **Mark as New Product Launch** (just above Save to Library) for a competitor's new launch. The dashboard then shows a **NEW LAUNCH** badge on that product for 28 days and lists it under the **New Launch** filter. After 28 days the badge disappears by itself. Saving the product again with the box ticked starts the 28 days again.
5b. **Product description** (under Single key message): the opening overview paragraph the seller wrote. The AI button fills it (the seller's own wording; if the seller wrote no opening paragraph, the AI writes a short 2 to 4 sentence overview in the same language). You can edit it before saving, and in the dashboard with ✏️ Edit. It shows as its own card on Product detail and as a row under Single key message in **Compare complete description**, Copy table and Download Excel. Products saved before this version show "Not captured yet" until you run the AI reading again or type it.
6. **Main category** (just above Category in the side panel): Skincare, Decorative or Personal Care. It is filled in from the category name and from the AI reading; change it with the dropdown if it is wrong. Older saved products get it worked out automatically from their category.
7. **Open my library** opens the dashboard:
   - **Main page (Market radar)**: **All | Skincare | Decorative | Personal Care** tabs filter everything below. A thin row of totals; the **New Launch radar** (marked in the last 28 days, with price and month saved); **Categories** with average price per ml/g; **Top key ingredients**. Click an ingredient (or type in **Search ingredient / active…**) to open its **Ingredient landscape**: how many saved products use it, adoption per category (e.g. "3 of 4 Lip Serums · 2 of 3 Cushions") and, for each product, the claim attributed to that ingredient.
   - **Product library**: the same main category tabs, then category pills; search by brand, product, claim or ingredient, sort; click a row to open it.
     - Tick the box left of any row (up to 6). A bar at the bottom shows **X products selected · Compare now →** and **Clear**. **Compare now** opens Compare product with exactly those products. The ticks stay while you switch tabs or open a product and come back, until you close the browser tab.
   - **Product detail**: read-only by default. **✏️ Edit** changes main category, key message, claims, RTB, ingredients, how to use, texture/finish/skin, shades and notes, then **Save changes**. **Show slide sources** (off by default) shows the "Slide n / Desc n" labels and source tags.
   - **Compare product**: starts empty. **+ Add product** (search by brand or name), pick 2 to 6. **Compare PDP** has a **Filter slides** dropdown (All slides, Shades, Ingredients, Hero Claim, How to Use). The first time you pick a filter, press **✨ Detect slide types**: the AI reads each product's pictures once (Gemini key from AI Settings needed) and the result is saved on the product. Compare PDP, **Compare complete description** and **Claim matrix** share the same chosen products. Remove one with the small **×**; click a product name to open its detail.
     - **+ Add product** is now a checklist: tick several products without it closing (search, **All | Skincare | Decorative | Personal Care** tabs and **Select all matching** are inside). At 6 products the unticked rows are disabled; untick one to swap. Press **Done**, click outside, or press Esc to close.
     - **Save set** names the products now chosen (for example "Lip Serum Benchmark"); saving the same name again updates it. **Saved sets ▾** lists your sets: click one to load it (replaces the chosen products), **×** then **Delete?** removes it. Sets are kept in the browser's extension storage (key `compareSets`), so they stay after you close Chrome. Products that were deleted from the library are skipped when a set is loaded.
   - **Claim matrix**: press **✨ Analyze Claims Matrix** (the AI is never called by itself). By default each cell shows ✓ or —; **Show wording** shows only the short phrase of the product's page that supports the claim (hover for the full line). The result is remembered while the tab is open.
   - **✨ Competitor Pattern** (Claim matrix only; Compare PDP stays purely visual): after **✨ Analyze Claims Matrix** (or **Regenerate**), a 3-point card appears above the matrix: market table stakes vs. white space; communication and hook angle; formula and price-to-benefit (price per ml/g is worked out by the dashboard, not by the AI). Click **▾ ✨ Competitor Pattern** to hide or show it; Regenerate redoes both matrix and pattern. Like the matrix, it is made only on click and remembered for that exact set of products while the tab is open.
   - Top right: **Export HD Image** (Compare PDP: one sharp PNG of the slides currently showing, left to right), **Copy table** (pastes into Google Sheets or Excel with one list item per line) and **Download Excel** (formatted .xlsx).

## Side panel cleanups (0.8.3)
- **Save to Library** now only saves to the dashboard library: the "Also download banners and text to my computer" box and the second "Open my library" link under the AI button are gone (use **Open Product Library ↗** in the header).
- The header shows **Open Product Library ↗** and **Re-scan** (the "Some details missing" badge is gone; the yellow reload notice in the form still appears when details did not load).
- **AI Settings**: with no Gemini key saved, the key box shows by itself. Once a key is saved the box tucks away and only a small **⚙** in the header remains; press it to change the key, model or picture option.
- **Short first view**: the AI fields stay hidden until you press **✨ Analyze Banners & Description with AI** (or the product already has AI data from earlier work on it). They then appear right under the button: Single key message, Product description, Hero claims, RTB, Key ingredients, How to use, Texture, Finish, Target skin type.

## Extraction accuracy (0.8.3)
- **Price** is only taken from text that contains "Rp" (for example Rp47.250 or Rp34.155 - Rp45.000; a range gives the lowest amount). Text with terjual, sold, penilaian, rating, ulasan or stok is never a price. The AI can only fill an empty Price box, and only with an Rp amount that is really written in the text it was given.
- **Shades** come only from the option buttons below the price. Ratings (4.9, 4,9k rating), "10RB+ Terjual", stock (Tersisa 5), shipping, vouchers, quantity and the cart / buy buttons are filtered out. Press Analyze and the AI also cleans the list.
- **Brand and Product name**: the AI now sees the page title and the shop name separately and gives a clean brand and a clean product name (no [PROMO], [COD], [BPOM], freebies or size). It fills these boxes unless you typed in them yourself. Hero Claims and RTB are unchanged.

## If something is still read wrongly

Click **Copy debug info** at the bottom of the panel (while on that product page) and paste it to Claude.
It only contains page address, what was found, and the names of Shopee data requests; no passwords or personal data.

## 0.9.0: dashboard upgrades
- **Main page:** Top key ingredients is a horizontal bar chart (name, bar sized by product count, count). Click a bar to open the Ingredient Landscape right below; click again to close.
- **Compare product:** two grouped cards: "Selected products" (chips, Add product, Save set, Saved sets) and "View" (Compare PDP / Compare complete description / Claim matrix). Compare PDP itself is unchanged.
- **Claim matrix:** one toolbar directly above the table header: `Claims | Ingredients & Formula`, Show wording, Copy table, Download Excel. Column headers show the price. ✓ cells have a soft rose tint when Show wording is off.
  - Ingredients & Formula mode reads the saved AI reading (key ingredients, texture, finish). It makes no AI call. Show wording on reveals the function stated for each ingredient.
  - Copy table and Excel follow the mode and include the price row.
- **Product detail:** in Edit mode, Category is a combobox (type, or pick from categories already in the library; new names are offered as "Use … as a new category"). Saves with Main Category.

## 0.9.1
- **Compare product, + Add product:** back to the simple search dropdown: type to search (brand, name, category), click a product to add it and close. No checkboxes, category tabs, Select all or Done. Library multi-select, Saved sets and everything else are unchanged.

## 0.9.2
- **Compare product:** back to the compact top bar (tabs, then + Add product, Save set, Saved sets; chips underneath in Claim matrix). The Add product list opens left-aligned under its button.
- **Claim matrix:** the price per ml/g is no longer shown in the column headers or in Copy table / Excel (the price stays).

## 0.10.0
- **Up to 10 products** can be compared (Add product list, Product library tick boxes and the Compare now bar, Saved sets, all labels). Older saved sets still load.
- **Wide tables:** Compare complete description and the Claim matrix (both modes) scroll sideways with the first column (Field / Claim / Ingredient, and the Key actives / Formula titles) kept in view. Product columns are at least 155 px wide.
- **Export HD Image** is also capped by height (30,000 px), so 10 rows are captured in full.

## 0.11.0: storage tidy-up (no visible change)
All reading and writing of the library now goes through one file, `src/store.js`. It still keeps everything in this browser (`chrome.storage.local`), so your saved products, notes and sets are untouched. This prepares the move to a shared online database. Nothing needs to be migrated: update the files in the same folder and click the refresh arrow on `chrome://extensions`.

## 0.11.1: + Add product is a checklist again
The `+ Add product` button stays where it was. Its pop-up now has checkboxes, stays open while you tick, shows **Select all matching (N)** after you type a search (it fills the free places up to the 10-product limit) and has a **Done** button. Untick a product to remove it. Esc or a click outside also closes it.

## 0.12.0: shared database (Supabase) and website
- New `src/store.js` cloud adapter: the same pages can read and write a shared Supabase database. The extension still uses this Chrome's own library (`useCloud: false` in `src/config.js`), so nothing changes for you yet.
- New page `dashboard/migrate.html` (Main page → "Shared database tools"): download a backup of this Chrome's library, upload it once to the shared database, back up the shared database. It never deletes anything.
- The dashboard pages also work as a website (see the separate website zip): AI buttons there say they work only in the extension; "Open on Shopee" opens a normal tab.
- Your name ("Saved by") and the Gemini key stay in your own browser; they are never sent to the shared database.

## 0.13.0: the extension saves to the shared database + banner pictures are copied
- `src/config.js` now has `useCloud: true`: the Product library, Compare and the side panel read and save in the shared database, so everyone sees new products at once. Your old library in this Chrome is NOT deleted. To go back at any time, change `useCloud: true` to `useCloud: false` in `src/config.js` and refresh the extension.
- The side panel no longer downloads the whole library on every scan: it only asks for the category names and the last saved date of that product.
- After you save a product, its banner pictures are copied in the background into the shared storage (keep the side panel open for a minute). Pictures not copied yet (or that failed) can be finished at Main page → Shared database tools → "Copy banner pictures now". The product keeps its original Shopee picture addresses; pages use the copy when it exists, so the website can show and export them.
- Your name ("Saved by"), the last category and the Gemini key stay in your own browser.

## 0.14.0: AI buttons work on the website through the extension (key entered once)
- The two AI buttons of the dashboard (Claim matrix, Detect slides) now also work on the website. The website passes the request to this extension (same Chrome), which calls Gemini with the key you saved in the extension. The key is typed once, in the extension, and is never stored on the website or in the shared database.
- New file `src/bridge.js`, loaded by the manifest only on `https://benzwiftt.github.io/civil-war-dashboard/*`. It passes on only those two request types and refuses everything else. If you move the website to another address, change that address in `manifest.json` (`content_scripts`).
- Needs: this extension (0.14.0 or newer) in the same Chrome as the website, with the Gemini key saved. Without it the buttons show a clear message and everything already analysed stays visible.
- After updating the extension, reload the website tab (Cmd+Shift+R) once, so the bridge attaches.

## 0.15.0: side panel buttons open the live website
- `Open Product Library ↗` opens `.../library.html` and `Open my library` opens `.../home.html` of the live website (address in `src/config.js` → `siteUrl`), in a new tab.
- If you ever switch the shared database off (`useCloud: false`), both buttons open the pages inside the extension again.
- Saving from the side panel already goes straight into the shared database (since 0.13.0). There is nothing to upload by hand.
